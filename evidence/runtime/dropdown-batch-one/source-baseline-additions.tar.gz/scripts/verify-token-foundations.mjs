import { existsSync, readFileSync, readdirSync, realpathSync, statSync } from "node:fs";
import { createHash } from "node:crypto";
import { join, relative, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { parseSync } from "vite";
import { colorRegistry, colorTokenOutputs, colorToCss, validateColorUse, resolveColor, resolveColorSurface, measureColorContrast } from "../packages/foundations/src/color-registry.ts";
import { semanticColorTokens } from "../packages/foundations/src/token-contract.ts";
import { validateButtonColorRecipe } from "../packages/foundations/src/button-token-contract.ts";
import { generateTokenFoundations } from "./generate-token-foundations.mjs";
import { getTokenFoundationOutputs, getTagColorConsumers, measureTagColorRecipe } from "./token-foundation-outputs.mjs";
import { validateProtectedTailwindSource } from "./verify-tailwind-b2.mjs";
import { hasTagRefinementAuthorization, hasInputRefinementAuthorization, buttonTextContrastException, hasOptionButtonContentRefinementAuthorization, hasOptionButtonRefinementAuthorization, hasQuestionNumberRefinementAuthorization, parseYamlSubset, validateTokenFoundationsV1Phase } from "./verification-helpers.mjs";

const consumerDirectory = "apps/playground/src/docs/token-foundations/";
const strings = (value) => typeof value === "string" ? [value] : value && typeof value === "object" ? Object.values(value).flatMap(strings) : [];
const escapeRegex = (value) => value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
const categorySource = /\b(?:bg|text|border|outline|ring)-rain-(?:category|local)-|--rain-(?:category|local)-[a-z0-9]|token-classes\.generated|\b(?:colorTokenOutputs|localColorRecipeOutput)\b/;

/** Exact reviewed definitions; this does not grant their files a Category-color exemption. */
/** @param {{filePath: string, source: string, outputs?: ReturnType<typeof getTokenFoundationOutputs>, root?: string, pendingContrastFindings?: any[], pendingEligibilityFindings?: any[]}} options */
export function validateRegisteredRecipeColors({ filePath, source, outputs = getTokenFoundationOutputs(), root = process.cwd(), pendingContrastFindings = [], pendingEligibilityFindings = [] }) {
  const failures = [], ranges = [];
  const recipes = outputs.colorRecipeConsumers.filter((entry) => entry.filePath === filePath);
  const cssConsumers = outputs.colorCssConsumers.filter((entry) => entry.filePath === filePath);
  const questionNumberScope = ["packages/ui/src/question-number/question-number.styles.ts", "apps/playground/src/docs/components/question-number-page.css"].includes(filePath);
  const questionNumberAuthorized = questionNumberScope && existsSync(join(root, "status/current-phase.yaml"))
    && hasQuestionNumberRefinementAuthorization(parseYamlSubset(readFileSync(join(root, "status/current-phase.yaml"), "utf8")));
  const optionButtonAuthorized = filePath === "packages/ui/src/option-button/option-button.styles.ts" && existsSync(join(root, "status/current-phase.yaml"))
    && hasOptionButtonRefinementAuthorization(parseYamlSubset(readFileSync(join(root, "status/current-phase.yaml"), "utf8")));
  const optionButtonContentAuthorized = optionButtonAuthorized
    && hasOptionButtonContentRefinementAuthorization(parseYamlSubset(readFileSync(join(root, "status/current-phase.yaml"), "utf8")));
  const inputPhase = ["packages/ui/src/input/input.styles.ts", "packages/ui/src/input/form-item.tsx"].includes(filePath) && existsSync(join(root, "status/current-phase.yaml"))
    ? parseYamlSubset(readFileSync(join(root, "status/current-phase.yaml"), "utf8")) : null;
  const inputAuthorized = hasInputRefinementAuthorization(inputPhase);
  const tagScope = ["packages/ui/src/tag/tag.styles.ts", "apps/playground/src/docs/components/tag-page.css"].includes(filePath);
  const tagAuthorized = tagScope && existsSync(join(root, "status/current-phase.yaml"))
    && hasTagRefinementAuthorization(parseYamlSubset(readFileSync(join(root, "status/current-phase.yaml"), "utf8")));
  const expectedTags = getTagColorConsumers();
  if (tagScope && (!tagAuthorized || JSON.stringify(recipes) !== JSON.stringify(expectedTags.colorRecipeConsumers.filter((entry) => entry.filePath === filePath))
    || JSON.stringify(cssConsumers) !== JSON.stringify(expectedTags.colorCssConsumers.filter((entry) => entry.filePath === filePath)))) failures.push("Tag consumer metadata requires the exact authorized palette, roles, thresholds and paint states");
  const inputVisualRevisionAuthorized = inputAuthorized && Boolean(inputPhase.componentRefinements.input.visualRevision);
  const inputConsumerContent = {
    inputRootRecipe: "text", inputControlClassName: "text", inputAffixClassName: "text", inputSuffixTextClassName: "text", inputIconColors: "decorative",
    inputClearClassName: "meaningful-icon", inputCountRecipe: "text", formItemColors: "text",
  };
  const inputContrastUse = (use) => inputAuthorized && use.evidenceRef === "docs/plans/2026-09-08-input-design.md" && (
    (use.recipeId?.startsWith("input-root-") && use.role === "border" && use.content === "essential-boundary")
    || (use.recipeId?.startsWith("input-count-overflow-") && use.tokenId === "Text/Red/1" && use.content === "text")
    || (inputVisualRevisionAuthorized && use.role === "text" && use.content === "text" && (
      (/^input-(?:suffix-text|count)-(?:default|editing|warning|error)$/.test(use.recipeId ?? "") && use.tokenId === "Text/Neutral/5")
      || (use.recipeId === "input-form-item-warning" && use.tokenId === "Text/Orange/1"))));
  const optionContentSymbols = ["optionFeedbackControlColors"];
  const checkColor = (use, label, pendingReview = false) => {
    try { validateColorUse(use); }
    catch (error) {
      const insufficient = error.message.match(/^Insufficient contrast: ([0-9.]+) < ([0-9.]+)$/);
      if (pendingReview && insufficient && (questionNumberAuthorized || (optionButtonContentAuthorized && use.recipeId.startsWith("option-button-content-")) || inputContrastUse(use))) pendingContrastFindings.push({
        status: "pending-review", acceptedException: false, filePath, recipeId: use.recipeId,
        tokenId: use.tokenId, content: use.content, theme: use.theme,
        parentSurfaceId: use.parentSurfaceId, parentBackgroundId: use.parentBackgroundId ?? null,
        actual: Number(insufficient[1]), minimum: Number(insufficient[2]), evidenceRef: use.evidenceRef,
      });
      else if (pendingReview && inputContrastUse(use) && use.recipeId.startsWith("input-count-overflow-")
        && use.parentSurfaceId === "Fill/Orange/Solid/3"
        && error.message === "These subtle surfaces require Neutral or same-family foregrounds") {
        const actual = measureColorContrast(resolveColor(use.tokenId, use.theme), resolveColorSurface(use.parentSurfaceId, use.theme, use.parentBackgroundId));
        const finding = { status: "pending-review", acceptedException: false, filePath, recipeId: use.recipeId,
          tokenId: use.tokenId, content: use.content, theme: use.theme, parentSurfaceId: use.parentSurfaceId,
          parentBackgroundId: use.parentBackgroundId ?? null, evidenceRef: use.evidenceRef };
        pendingEligibilityFindings.push({ ...finding, reason: error.message, actual, minimum: 4.5 });
        if (actual < 4.5) pendingContrastFindings.push({ ...finding, actual, minimum: 4.5, measurementOnly: true });
      } else failures.push(`${label}: ${error.message}`);
    }
  };
  const checkUse = (use, parents, label, pendingReview = false) => {
    if (!existsSync(join(root, use.evidenceRef?.split("#")[0] ?? ""))) failures.push(`Missing color consumer evidence: ${label}`);
    for (const theme of ["light", "dark"]) for (const parent of parents) {
      checkColor({ ...use, theme, parentSurfaceId: parent }, `${label} ${theme} ${parent}`, pendingReview);
    }
  };
  if (recipes.length) {
    const parsed = parseSync(filePath, source);
    if (parsed.errors.length) return [`Cannot parse registered recipe: ${filePath}`];
    const declarations = [], imports = [];
    const visit = (node) => {
      if (!node || typeof node !== "object") return;
      if (node.type === "VariableDeclarator") declarations.push(node);
      if (node.type === "ImportDeclaration") imports.push(node);
      for (const value of Object.values(node)) if (Array.isArray(value)) value.forEach(visit); else if (value && typeof value === "object") visit(value);
    };
    visit(parsed.program);
    const literal = (node) => {
      if (node?.type === "TSAsExpression" || node?.type === "TSSatisfiesExpression") return literal(node.expression);
      if (node?.type === "Literal") return node.value;
      if (node?.type === "ArrayExpression") return node.elements.map(literal);
      if (node?.type === "ObjectExpression") return Object.fromEntries(node.properties.map((property) => {
        if (property.type !== "Property" || property.computed || property.kind !== "init") throw new Error("Color recipes must be literal objects");
        return [property.key.name ?? property.key.value, literal(property.value)];
      }));
      throw new Error("Color recipes must be static literals");
    };
    for (const consumer of recipes) {
      const matches = declarations.filter((node) => node.id?.name === consumer.symbol);
      try {
        if (matches.length !== 1) throw new Error("Expected one registered recipe definition");
        const init = matches[0].init;
        const callee = consumer.kind === "cva" ? "cva" : "defineRainLocalRecipe";
        const from = consumer.kind === "cva" ? "class-variance-authority" : "@rain-next/ui";
        if (consumer.kind !== "static" && (init?.type !== "CallExpression" || init.callee?.name !== callee
          || !imports.some((entry) => entry.source.value === from && entry.specifiers.some((part) => part.imported?.name === callee && part.local.name === callee)))) throw new Error("Registered recipe must use its declared recipe factory");
        if (consumer.kind === "static" && !questionNumberAuthorized && !optionButtonAuthorized && !(inputAuthorized && Object.hasOwn(inputConsumerContent, consumer.symbol))
          && !(tagAuthorized && ["tagColorPaints", "tagSolidPaints"].includes(consumer.symbol))) throw new Error("Static color recipe requires its exact component authorization");
        if (optionContentSymbols.includes(consumer.symbol) && (!optionButtonContentAuthorized || consumer.refinement !== "option-button-content")) throw new Error("OptionButton content color recipe requires its separate exact authorization");
        if (consumer.refinement === "option-button-content" && !optionContentSymbols.includes(consumer.symbol)) throw new Error("OptionButton content authorization cannot expand the accepted selection recipes");
        const actual = literal(consumer.kind === "static" ? init : init.arguments[consumer.kind === "cva" ? 1 : 0]);
        const reviewed = ["cva", "static"].includes(consumer.kind) ? actual : Object.fromEntries(Object.keys(consumer.definition).map((key) => [key, actual[key]]));
        if (JSON.stringify(reviewed) !== JSON.stringify(consumer.definition)) throw new Error("Registered color state routing differs from the reviewed definition");
        if (consumer.kind === "cva" && categorySource.test(source.slice(init.arguments[0].start, init.arguments[0].end))) throw new Error("Unregistered base color in CVA recipe");
        ranges.push([init.start, init.end]);
      } catch (error) { failures.push(`${filePath} ${consumer.symbol}: ${error.message}`); }
      const inputReview = inputAuthorized && Object.hasOwn(inputConsumerContent, consumer.symbol);
      const optionReview = consumer.refinement === "option-button-content" && consumer.symbol === "optionFeedbackControlColors";
      if (tagAuthorized && ["tagColorPaints", "tagSolidPaints"].includes(consumer.symbol)) {
        for (const recipe of consumer.recipes) for (const theme of ["light", "dark"]) for (const parentId of consumer.parentSurfaces) for (const state of recipe.states) {
          try {
            const measured = measureTagColorRecipe(recipe, theme, parentId, state);
            if (state === "disabled") continue;
            const parts = state.startsWith("close-") ? [["close-icon", recipe.icon, measured.iconContrast, 3]]
              : [["label", recipe.foreground, measured.textContrast, 4.5], ["selection-icon", recipe.selectionIcon, measured.selectionIconContrast, 3],
                ...(recipe.boundary ? [[recipe.boundaryScope, recipe.boundary, measured.boundaryContrast, 3]] : [])];
            for (const [part, use, actual, minimum] of parts) if (actual < minimum) pendingContrastFindings.push({
              status: "pending-review", acceptedException: false, filePath, recipeId: recipe.id, color: recipe.color, appearance: recipe.appearance, state, part,
              tokenId: use.tokenId, content: use.content, theme, parentSurfaceId: recipe.background?.tokenId ?? parentId, parentBackgroundId: parentId,
              ...(use.alpha === undefined ? {} : { alpha: use.alpha, alphaOperation: use.alphaOperation }),
              actual, minimum, evidenceRef: use.evidenceRef, paintScope: "tag-isolated-group",
            });
          } catch (error) { failures.push(`${recipe.id} ${theme} ${parentId} ${state}: ${error.message}`); }
        }
        continue;
      }
      if (optionReview && JSON.stringify(consumer.recipes.map(({ state, presentation }) => `${state}:${presentation}`)) !== JSON.stringify(["correct:label", "correct:symbol", "wrong:label", "wrong:symbol"])) failures.push("OptionButton review must retain both text and meaningful-icon presentations for each result");
      for (const recipe of consumer.recipes) {
        const foregroundContent = inputReview ? inputConsumerContent[consumer.symbol] : optionReview ? (recipe.presentation === "symbol" ? "meaningful-icon" : "text") : consumer.kind === "static" && consumer.symbol !== "questionNumberMarkerColors" ? "text" : "meaningful-icon";
        if (consumer.kind === "static" && consumer.foregroundContent !== (optionReview ? "text-and-meaningful-icon" : foregroundContent)) failures.push(`Static color recipe must preserve its declared text or meaningful-icon role: ${consumer.symbol}`);
        if (recipe.foreground.content !== (recipe.state === "disabled" ? "disabled" : foregroundContent)) failures.push(`Registered foreground must keep its real content contrast: ${recipe.id}`);
        const pendingReview = ["pending-review", "declared-review"].includes(consumer.contrastReview) && (inputReview || questionNumberAuthorized || (optionButtonContentAuthorized && optionReview));
        for (const theme of ["light", "dark"]) for (const parent of consumer.parentSurfaces) {
          const label = `${recipe.id} ${theme} ${parent}`;
          if (recipe.background) checkColor({ ...recipe.background, theme, parentSurfaceId: parent }, label);
          if (inputReview && consumer.symbol === "inputRootRecipe" && recipe.boundary?.content !== (recipe.state === "disabled" ? "disabled" : "essential-boundary")) failures.push(`Input boundaries must keep their essential-boundary role: ${recipe.id}`);
          if (recipe.boundary) checkColor({ ...recipe.boundary, theme, parentSurfaceId: parent }, label, pendingReview);
          checkColor({ ...recipe.foreground, theme, parentSurfaceId: recipe.background?.tokenId ?? parent,
            ...(recipe.background ? { parentBackgroundId: parent } : {}) }, label, pendingReview);
        }
        if (!existsSync(join(root, recipe.foreground.evidenceRef.split("#")[0]))) failures.push(`Missing color consumer evidence: ${recipe.id}`);
      }
    }
  }
  if (cssConsumers.length) {
    const found = new Set();
    const uncommented = source.replace(/\/\*[\s\S]*?\*\//g, (comment) => " ".repeat(comment.length));
    for (const block of uncommented.matchAll(/([^{}]+)\{([^{}]*)\}/g)) {
      const selector = block[1].trim().replace(/\s+/g, " ");
      const bodyStart = block.index + block[0].indexOf("{") + 1;
      for (const declaration of block[2].matchAll(/([a-z-]+)\s*:\s*([^;{}]+);/g)) {
        const property = declaration[1], value = declaration[2].trim();
        if (!categorySource.test(value)) continue;
        const consumer = cssConsumers.find((entry) => entry.selector === selector && entry.property === property && entry.value === value);
        if (!consumer || found.has(consumer)) { failures.push(`Unregistered Category CSS paint ${filePath}: ${selector} ${property}`); continue; }
        found.add(consumer);
        const output = colorTokenOutputs.find((entry) => entry.id === consumer.use.tokenId);
        if (!output || !value.includes(`var(${output.variable})`)) failures.push(`Category CSS source mismatch: ${selector} ${property}`);
        checkUse(consumer.use, consumer.parentSurfaces, `${selector} ${property}`, ["pending-review", "declared-review"].includes(consumer.contrastReview));
        ranges.push([bodyStart + declaration.index, bodyStart + declaration.index + declaration[0].length]);
      }
    }
    for (const consumer of cssConsumers) if (!found.has(consumer)) failures.push(`Missing registered CSS paint: ${filePath} ${consumer.selector} ${consumer.property}`);
  }
  let unregistered = source;
  for (const [start, end] of ranges.sort((a, b) => b[0] - a[0])) unregistered = unregistered.slice(0, start) + " ".repeat(end - start) + unregistered.slice(end);
  if (categorySource.test(unregistered)) failures.push(`Category/local colors require registered Token consumer metadata: ${filePath}`);
  if (filePath.endsWith(".css")) failures.push(...validateTokenConsumerCss({ filePath, source: unregistered }));
  return [...new Set(failures)];
}

function attribute(node, name) {
  const value = node.attributes.find((part) => part.type === "JSXAttribute" && part.name.name === name)?.value;
  if (value?.type === "Literal") return String(value.value);
  if (value?.type === "JSXExpressionContainer" && value.expression.type === "Literal") return String(value.expression.value);
}

function matches(node, selector) {
  const attr = selector.match(/^\[([a-z-]+)="([^"]+)"\]$/);
  if (attr) return attribute(node, attr[1]) === attr[2];
  return selector.startsWith(".") && (attribute(node, "className") ?? "").split(/\s+/).includes(selector.slice(1));
}

function inScope(node, selector, paintClass) {
  for (let current = node; current; current = current.parent) {
    const element = current.type === "JSXElement" ? current.openingElement : current;
    if (element.type === "JSXOpeningElement" && matches(element, selector) && (!paintClass || (attribute(element, "className") ?? "").split(/\s+/).includes(paintClass))) return true;
  }
  return false;
}

function renderedTheme(node) {
  for (let current = node; current; current = current.parent) {
    if (current.type !== "JSXOpeningElement" && current.type !== "JSXElement") continue;
    const element = current.type === "JSXElement" ? current.openingElement : current;
    if (!element.attributes.some((part) => part.type === "JSXAttribute" && part.name.name === "data-rain-theme")) continue;
    const theme = attribute(element, "data-rain-theme");
    if (theme !== "light" && theme !== "dark") throw new Error("Actual color consumers require a literal supported theme boundary");
    return theme;
  }
  return "light";
}

function emittedPaint(outputs, entry) {
  const utility = outputs.utilities.find((item) => item.className === entry.className);
  const block = outputs.scopedCss.match(new RegExp(`${escapeRegex(entry.scope)} \\.${escapeRegex(entry.className)} \\{([^}]+)\\}`))?.[1];
  const value = utility?.declarations[entry.use.property] ?? block?.match(new RegExp(`${escapeRegex(entry.use.property)}: ([^;]+);`))?.[1];
  const variable = value?.match(/^var\((--rain-[a-z0-9-]+)\)$/)?.[1];
  if (variable?.startsWith("--rain-category-")) return outputs.colorThemes[entry.use.theme ?? "light"]?.[variable];
  return variable ? outputs.variables[variable] ?? outputs.scopedCss.match(new RegExp(`${escapeRegex(variable)}: ([^;]+);`))?.[1] : value;
}

/** A bounded JSX checker: public inventory lookups and same-file class forwarding stay declarative. */
export function validateTokenConsumerSource({ filePath, source, outputs = getTokenFoundationOutputs(), root = process.cwd() }) {
  const failures = [];
  const parsed = parseSync(filePath, source);
  if (parsed.errors.length) return [...failures, `Cannot parse Token consumer ${filePath}: ${parsed.errors.map((error) => error.message).join("; ")}`];
  const tree = parsed.program;
  const sourceText = (node) => source.slice(node.start, node.end);
  const nodes = [], allNodes = [], bindings = [], initializers = new Map(), inventories = new Map(), helpers = new Map();
  const colorConsumers = outputs.colorConsumers.filter((entry) => entry.filePath === filePath);
  const displays = outputs.displayConsumers.filter((entry) => entry.filePath === filePath);
  const allowed = new Set([
    ...strings(outputs.classNames), ...outputs.utilities.map((item) => item.className),
    ...Object.keys(outputs.themeVariables).filter((name) => name.startsWith("--spacing-rain-")).flatMap((name) =>
      ["h", "w", "min-h", "min-w", "max-h", "max-w", "size"].map((prefix) => `${prefix}-${name.slice("--spacing-".length)}`)),
    ...Object.keys(semanticColorTokens).flatMap((name) => ["text", "bg", "border", "outline", "ring"].map((prefix) => `${prefix}-rain-${name}`)),
  ]);
  // The older guard scans substrings. Hide only full registered classes so a
  // category name such as text-neutral-1 is not mistaken for Tailwind's palette.
  const legacySource = source.replace(/[A-Za-z][A-Za-z0-9_:/!.-]*/g, (word) => allowed.has(word) ? "registered-token" : word);
  failures.push(...validateProtectedTailwindSource({ filePath, source: legacySource }));
  const bindingNames = (pattern) => {
    if (!pattern) return [];
    if (pattern.type === "Identifier") return [pattern.name];
    if (pattern.type === "ObjectPattern") return pattern.properties.flatMap((part) => bindingNames(part.value ?? part.argument));
    if (pattern.type === "ArrayPattern") return pattern.elements.flatMap(bindingNames);
    if (pattern.type === "AssignmentPattern") return bindingNames(pattern.left);
    if (pattern.type === "RestElement") return bindingNames(pattern.argument);
    return [];
  };
  const visit = (node, parent) => {
    if (!node || typeof node !== "object" || typeof node.type !== "string") return;
    Object.defineProperty(node, "parent", { value: parent });
    allNodes.push(node);
    if (node.type === "VariableDeclarator") bindings.push(...bindingNames(node.id));
    if (["FunctionDeclaration", "FunctionExpression", "ArrowFunctionExpression"].includes(node.type)) bindings.push(...bindingNames(node.id), ...node.params.flatMap(bindingNames));
    if (node.type === "ClassDeclaration" || node.type === "CatchClause") bindings.push(...bindingNames(node.id ?? node.param));
    if (node.type === "JSXOpeningElement") nodes.push(node);
    if (node.type === "VariableDeclarator" && node.id.type === "Identifier" && node.init) {
      if (initializers.has(node.id.name)) failures.push(`Ambiguous duplicate local binding in Token consumer ${filePath}: ${node.id.name}`);
      initializers.set(node.id.name, node.init);
    }
    if (node.type === "ImportDeclaration") {
      for (const item of node.specifiers.filter((item) => item.type === "ImportSpecifier")) {
        const original = item.imported.name;
        if (["rainCn", "defineRainLocalRecipe"].includes(original) && node.source.value === "@rain-next/ui") helpers.set(item.local.name, original);
        if (original === "tokenClassNames" && /token-classes\.generated$/.test(node.source.value)) inventories.set(item.local.name, outputs.classNames);
        if (original === "typographyUtilityClassNames" && node.source.value === "@rain-next/foundations") inventories.set(item.local.name, outputs.classNames.typography);
        if (original === "iconSizeClassNames" && node.source.value === "@rain-next/foundations") inventories.set(item.local.name, outputs.classNames.iconSize);
        if (original === "inputSizeClassNames" && node.source.value === "@rain-next/foundations") inventories.set(item.local.name, outputs.classNames.inputSize);
        if (original === "inputClearSizeClassName" && node.source.value === "@rain-next/foundations") inventories.set(item.local.name, outputs.classNames.inputClearSize);
        if (original === "selectSizeClassNames" && node.source.value === "@rain-next/foundations") inventories.set(item.local.name, outputs.classNames.selectSize);
        if (original === "selectValueHeightClassNames" && node.source.value === "@rain-next/foundations") inventories.set(item.local.name, outputs.classNames.selectValueHeight);
        if (original === "selectActionSizeClassName" && node.source.value === "@rain-next/foundations") inventories.set(item.local.name, outputs.classNames.selectActionSize);
        if (original === "iconButtonControlSizeClassNames" && node.source.value === "@rain-next/foundations") inventories.set(item.local.name, outputs.classNames.iconButtonControlSize);
        if (original === "colorTokenOutputs" && node.source.value === "@rain-next/foundations") inventories.set(item.local.name, colorTokenOutputs);
      }
    }
    for (const value of Object.values(node)) {
      if (Array.isArray(value)) value.forEach((child) => visit(child, node));
      else visit(value, node);
    }
  };
  visit(tree);
  for (const name of bindings) if (inventories.has(name) || helpers.has(name) || ["Map", "Object"].includes(name)) failures.push(`Trusted Token binding cannot be shadowed in ${filePath}: ${name}`);
  const rootBinding = (expression) => expression?.type === "MemberExpression" ? rootBinding(expression.object) : expression?.type === "Identifier" ? expression.name : undefined;
  for (const node of allNodes) {
    const target = node.type === "AssignmentExpression" ? node.left : node.type === "UpdateExpression" ? node.argument : undefined;
    if (target && (inventories.has(rootBinding(target)) || initializers.has(rootBinding(target)))) failures.push(`Token inventory bindings cannot be reassigned in ${filePath}`);
    if (node.type === "CallExpression") {
      const method = node.callee.type === "MemberExpression" && (node.callee.property.name ?? node.callee.property.value);
      const mutates = ["assign", "defineProperty", "defineProperties", "setPrototypeOf"].includes(method) && rootBinding(node.callee.object) === "Object" ? node.arguments[0] :
        ["set", "delete", "clear", "push", "pop", "shift", "unshift", "splice", "sort", "reverse", "fill", "copyWithin"].includes(method) ? node.callee.object : undefined;
      if (mutates && (inventories.has(rootBinding(mutates)) || initializers.has(rootBinding(mutates)))) failures.push(`Token inventory bindings cannot be mutated in ${filePath}`);
    }
  }


  function inventory(expression, seen = new Set()) {
    if (!expression) return undefined;
    if (expression.type === "TSAsExpression" || expression.type === "TSNonNullExpression") return inventory(expression.expression, seen);
    if (expression.type === "Literal") return expression.value;
    if (expression.type === "Identifier") {
      if (inventories.has(expression.name)) return inventories.get(expression.name);
      if (!seen.has(expression.name)) return inventory(initializers.get(expression.name), new Set([...seen, expression.name]));
    }
    if (expression.type === "CallExpression" && helpers.get(expression.callee.name) === "defineRainLocalRecipe") return inventory(expression.arguments[0], seen);
    if (expression.type === "NewExpression" && expression.callee.name === "Map") {
      const mapping = expression.arguments[0];
      const callback = mapping?.arguments?.[0];
      const parameter = callback?.params?.[0]?.name;
      const pair = callback?.body?.elements;
      if (mapping?.type === "CallExpression" && mapping.callee.property?.name === "map" && parameter &&
          pair?.length === 2 && pair[0].type === "MemberExpression" && pair[0].object.name === parameter &&
          pair[0].property.name === "id" && pair[1].name === parameter) {
        const values = inventory(mapping.callee.object, seen);
        if (Array.isArray(values)) return Object.fromEntries(values.map((value) => [value.id, value]));
      }
    }
    if (expression.type === "CallExpression" && expression.callee.type === "MemberExpression" && expression.callee.property.name === "get") {
      const values = inventory(expression.callee.object, seen);
      if (values) return Object.values(values);
    }
    if (expression.type === "ObjectExpression" && expression.properties.every((item) => item.type === "Property" && !item.computed)) {
      return Object.fromEntries(expression.properties.map((item) => [item.key.name ?? item.key.value, inventory(item.value, seen)]));
    }
    if (expression.type === "MemberExpression") {
      const object = inventory(expression.object, seen);
      const key = expression.computed ? (expression.property.type === "Literal" ? expression.property.value : undefined) : expression.property.name;
      if (object && key === undefined) return Object.values(object);
      return Array.isArray(object) ? object.flatMap((item) => item?.[key] ?? []) : object?.[key];
    }
  }

  function classes(expression, seen = new Set()) {
    if (expression.type === "Literal" && typeof expression.value === "string") return expression.value.split(/\s+/).filter(Boolean);
    if (expression.type === "TemplateLiteral" && expression.expressions.length === 0) return expression.quasis[0].value.cooked.split(/\s+/).filter(Boolean);
    if (expression.type === "ConditionalExpression") return [...classes(expression.consequent, seen), ...classes(expression.alternate, seen)];
    if (expression.type === "Identifier") {
      if (expression.name === "undefined") return [];
      if (initializers.has(expression.name) && !seen.has(expression.name)) return classes(initializers.get(expression.name), new Set([...seen, expression.name]));
      if (expression.name === "className") {
        let owner = expression.parent;
        while (owner && owner.type !== "FunctionDeclaration") owner = owner.parent;
        const calls = owner?.id && nodes.filter((node) => node.name.name === owner.id.name);
        if (owner && owner.parent?.type !== "ExportNamedDeclaration" && calls?.length &&
            owner.params.some((param) => param.type === "ObjectPattern" && param.properties.some((part) => part.value?.name === "className")) &&
            calls.every((node) => node.attributes.some((part) => part.type === "JSXAttribute" && part.name.name === "className"))) return [];
      }
    }
    if (expression.type === "Literal" && (expression.value === false || expression.value === null)) return [];
    if (expression.type === "CallExpression" && helpers.get(expression.callee.name) === "rainCn") return expression.arguments.flatMap((item) => classes(item, seen));
    if (expression.type === "MemberExpression") {
      const values = inventory(expression);
      if (values !== undefined) return strings(values).flatMap((value) => value.split(/\s+/).filter(Boolean));
    }
    failures.push(`Unregistered dynamic class expression in ${filePath}: ${sourceText(expression)}`);
    return [];
  }

  const nodeClasses = new Map(nodes.map((node) => {
    const value = node.attributes.find((part) => part.type === "JSXAttribute" && part.name.name === "className")?.value;
    return [node, value ? classes(value.type === "JSXExpressionContainer" ? value.expression : value) : []];
  }));
  function nearestSurface(node, entry) {
    // A foreground can share its surface node; background paint is carried by an ancestor.
    for (let current = entry.use.property === "background-color" ? node.parent.parent : node.parent; current; current = current.parent) {
      if (current.type !== "JSXElement") continue;
      const element = current.openingElement;
      const paints = nodeClasses.get(element).filter((name) => name.startsWith("bg-rain-") || displays.some((item) => item.kind === "comparison-canvas" && item.className === name));
      if (!paints.length) continue;
      if (paints.length !== 1) throw new Error("Parent surface has ambiguous background paint");
      return colorConsumers.find((candidate) => candidate.use.property === "background-color" && candidate.className === paints[0] && matches(element, candidate.selector) && inScope(element, candidate.scope));
    }
  }
  const matchedConsumers = new Set(), matchedDisplays = new Set();
  for (const node of nodes) {
    if (node.attributes.some((part) => part.type === "JSXSpreadAttribute")) failures.push(`Opaque JSX spread is forbidden in Token consumers: ${filePath}`);
    if (node.attributes.some((part) => part.type === "JSXAttribute" && part.name.name === "style")) failures.push(`Inline visual style is forbidden in ${filePath}; use registered Tokens`);
    for (const className of nodeClasses.get(node)) {
      const canvas = displays.find((entry) => entry.kind === "comparison-canvas" && entry.className === className);
      if (canvas) {
        let matchingTheme = false;
        try { matchingTheme = renderedTheme(node) === canvas.themeMapping; } catch { /* A comparison canvas needs a known theme. */ }
        if (canvas.displayOnly !== true || !matchingTheme || !matches(node, canvas.selector) ||
            canvas.scope !== colorTokenOutputs[0].displayScope || !outputs.scopedCss.includes(`${canvas.scope} .${className} {`)) failures.push(`Display-only canvas scope mismatch in ${filePath}`);
        else matchedDisplays.add(canvas);
        continue;
      }
      if (/^(bg|text)-rain-swatch-/.test(className)) {
        const entry = displays.find((item) => item.kind !== "comparison-canvas" && matches(node, item.selector));
        const foreground = className.startsWith("text-");
        const registered = colorTokenOutputs.some((output) => (foreground ? output.displayForegroundClassName : output.displayClassName) === className);
        if (!entry || !registered || entry.displayOnly !== true || entry.scope !== colorTokenOutputs[0].displayScope || attribute(node, "aria-hidden") !== "true"
          || (foreground && entry.kind !== "pairing-foreground") || (!foreground && entry.kind === "pairing-foreground")
          || (entry.kind.startsWith("pairing-") && (!entry.consumerScope || !inScope(node, entry.consumerScope)))) failures.push(`Display-only swatch escaped its registered decorative consumer in ${filePath}`);
        else matchedDisplays.add(entry);
        continue;
      }
      if ((className.includes("-rain-") || className.startsWith("rain-type-")) && !allowed.has(className)) failures.push(`Unregistered Rain utility in ${filePath}: ${className}`);
      if (!className.includes("-rain-category-") && !className.includes("-rain-local-")) continue;
      const entry = colorConsumers.find((item) => item.className === className && matches(node, item.selector));
      if (!entry) { failures.push(`Color utility needs matching consumer metadata in ${filePath}: ${className}`); continue; }
      matchedConsumers.add(entry);
      if (!inScope(node, entry.scope)) failures.push(`Color consumer scope mismatch in ${filePath}: ${entry.selector}`);
      try {
        if (renderedTheme(node) !== (entry.use.theme ?? "light")) throw new Error("Rendered theme does not match consumer metadata");
        const resolved = validateColorUse(entry.use);
        // Core supports leaf compositing math. This batch does not prove DOM group opacity.
        if (entry.use.componentOpacity !== undefined) throw new Error("Consumer componentOpacity needs DOM compositing evidence; not supported in this batch");
        if (entry.use.evidenceRef) {
          const evidencePath = resolve(root, entry.use.evidenceRef.split("#")[0]);
          let verified = false;
          try {
            const resolvedPath = realpathSync(evidencePath), fromRoot = relative(realpathSync(root), resolvedPath);
            verified = fromRoot !== ".." && !fromRoot.startsWith("../") && statSync(resolvedPath).isFile() && readFileSync(resolvedPath).length > 0;
          } catch { /* A claim without its local evidence is not verified. */ }
          if (!verified) throw new Error("Consumer evidence must be an existing nonempty repository file");
        }
        const token = colorRegistry.find((item) => item.id === entry.use.tokenId);
        const categoryOutput = colorTokenOutputs.find((item) => item.id === token?.id);
        if (className.includes("-rain-category-") && !categoryOutput?.utilities.some((item) => item.className === className && item.role === entry.use.role && item.property === entry.use.property)) throw new Error("Class, Token, role and property do not match");
        if (emittedPaint(outputs, entry) !== colorToCss(resolved.value)) throw new Error("Rendered color does not match the declared Alpha operation");
        if (entry.use.parentSurfaceId) {
          const parent = nearestSurface(node, entry);
          if (!parent || parent === entry || parent.use.tokenId !== entry.use.parentSurfaceId) throw new Error("Declared parent must match the nearest painted surface");
          if ((parent.use.theme ?? "light") !== (entry.use.theme ?? "light")) throw new Error("Parent surface theme does not match the consumer theme");
          if (parent.use.alpha !== undefined || parent.use.componentOpacity !== undefined) throw new Error("Parent paint overrides need explicit surface chain evidence");
          if (entry.use.parentBackgroundId && parent.use.parentSurfaceId !== entry.use.parentBackgroundId) throw new Error("Declared surface chain does not match the painted parent background");
        }
      } catch (error) { failures.push(`Invalid color consumer ${filePath} ${entry.selector}: ${error.message}`); }
    }
  }
  for (const entry of colorConsumers) if (!matchedConsumers.has(entry)) failures.push(`Missing registered color consumer ${filePath}: ${entry.selector}`);
  for (const entry of displays) if (!matchedDisplays.has(entry)) failures.push(`Missing registered display consumer ${filePath}: ${entry.selector}`);
  return [...new Set(failures)];
}

export function validateTokenConsumerCss({ filePath, source, outputs = getTokenFoundationOutputs() }) {
  const authored = source.replace(/\/\* token-foundations-v1:scoped-color:start[^]*?\/\* token-foundations-v1:scoped-color:end \*\//g, "").replace(/\/\*[^]*?\*\//g, "");
  const failures = [];
  if (/--rain-ref-|--rain-category-|--rain-local-|bg-rain-swatch-|#[\da-f]{3,8}\b|\b(?:rgb|hsl|oklch)\s*\(/i.test(authored)) failures.push(`Raw/private or unregistered Category/display color in ${filePath}`);
  const generatedSelectors = [...outputs.scopedCss.matchAll(/\.([a-z][a-z0-9-]*)\s*\{/g)].map((match) => match[1]);
  for (const className of generatedSelectors) {
    if (new RegExp(`\\.${escapeRegex(className)}(?![\\w-])`).test(authored)) failures.push(`Managed scoped selector cannot be redefined outside its generated section in ${filePath}: ${className}`);
  }
  if (new Set(generatedSelectors).size !== generatedSelectors.length) failures.push(`Managed scoped selectors have duplicate generated rules in ${filePath}`);
  const semanticVariables = new Set(Object.keys(semanticColorTokens).map((name) => `var(--rain-color-${name})`));
  for (const match of authored.matchAll(/(?:^|[;{])\s*([a-z-]+)\s*:\s*([^;}]+)/gi)) {
    const property = match[1].toLowerCase(), value = match[2].trim();
    if (!/^(?:color|.*-color|background(?:-image)?|fill|stroke|box-shadow|text-shadow|filter)$/.test(property)) continue;
    const inherited = ["transparent", "inherit", "currentcolor", "none"].includes(value.toLowerCase());
    const semanticName = value.match(/^var\(--rain-color-([a-z-]+)\)$/)?.[1];
    const validSemantic = semanticVariables.has(value) &&
      (!/^(?:color|fill|stroke|text-decoration-color)$/.test(property) || semanticName.startsWith("text-") || /^(?:semantic-(?:success|warning|error|info)|intelligence-foreground)$/.test(semanticName)) &&
      (!/^(?:border.*-color|outline-color)$/.test(property) || /^(?:border|focus)-/.test(semanticName)) &&
      !["box-shadow", "text-shadow", "filter", "background-image"].includes(property);
    if (!inherited && !validSemantic) failures.push(`Unregistered visual color declaration in ${filePath}: ${property}: ${value}`);
  }
  for (const match of authored.matchAll(/(?:^|[;{])\s*(border|outline)(?:-(?:top|right|bottom|left|block|inline))?\s*:\s*([^;}]+)/g)) {
    const remainder = match[2].replace(/var\(--rain-(?:color|line-thickness|space)-[a-z0-9-]+\)/g, "").replace(/\b(?:none|solid|dashed|dotted|double|transparent|inherit|currentColor)\b/g, "").replace(/\b(?:0|[\d.]+(?:px|rem|em))\b/g, "").trim();
    if (remainder) failures.push(`Unregistered border color in ${filePath}: ${match[2]}`);
  }
  return [...new Set(failures)];
}

function sourceFiles(root, directory) {
  if (!existsSync(join(root, directory))) return [];
  return readdirSync(join(root, directory), { withFileTypes: true }).flatMap((entry) => {
    const path = `${directory.replace(/\/$/, "")}/${entry.name}`;
    if (entry.isSymbolicLink() || ["dist", "node_modules", ".git"].includes(entry.name)) return [];
    return entry.isDirectory() ? sourceFiles(root, path) : /\.(?:tsx?|css)$/.test(path) && !/\.(?:test|generated)\./.test(path) ? [path] : [];
  });
}

export function validateButtonAliasSource(source, bridge, outputs = getTokenFoundationOutputs()) {
  const failures = [];
  const mappings = new Map([...bridge.matchAll(/--color-([a-z0-9-]+):\s*var\((--rain-button-[a-z0-9-]+)\)/g)]
    .map((match) => [match[1], match[2]]));
  for (const match of source.matchAll(/\b(bg|text|border|outline|ring)-(rain-button-[a-z0-9-]+)/g)) {
    const alias = mappings.get(match[2]);
    const value = outputs.variables[alias];
    if (!value) continue; // Geometry aliases have separate existing contracts.
    const variable = value.match(/var\((--rain-category-[a-z0-9-]+)\)/)?.[1];
    const token = colorTokenOutputs.find((entry) => entry.variable === variable);
    const property = { bg: "background-color", text: "color", border: "border-color", outline: "outline-color", ring: "box-shadow" }[match[1]];
    if (!token?.utilities.some((entry) => entry.property === property)) failures.push(`Button alias used across color roles: ${match[0]} (${alias})`);
  }
  return [...new Set(failures)];
}

export function verifyTokenFoundations({ root = process.cwd() } = {}) {
  const failures = [], outputs = getTokenFoundationOutputs();
  const exceptionCandidates = [], acceptedTextContrastExceptions = [], acceptedComponentContrastExceptions = [], pendingContrastFindings = [], pendingEligibilityFindings = [];
  const bridgePath = join(root, "packages/foundations/src/tailwind-theme.css");
  const buttonBridge = existsSync(bridgePath) ? readFileSync(bridgePath, "utf8") : "";
  for (const recipe of outputs.buttonColorRecipes) {
    for (const theme of ["light", "dark"]) for (const parent of ["Background/Neutral/1", "Background/Neutral/3"]) {
      try {
        const result = validateButtonColorRecipe(recipe, theme, parent);
        const exception = result.acceptedTextContrastException;
        if (exception) {
          const scope = buttonTextContrastException;
          const label = recipe.parts.find((entry) => entry.part === scope.part);
          if (recipe.variant !== scope.variant || recipe.tone !== scope.tone
            || !scope.states.includes(recipe.state) || !scope.themes.includes(theme) || !scope.parentSurfaces.includes(parent)
            || label?.use.tokenId !== scope.foreground || label.use.role !== "text" || label.use.content !== "text"
            || Object.keys(exception).sort().join(",") !== "actual,decisionSource,minimum"
            || exception.decisionSource !== scope.decisionSource || exception.minimum !== scope.minimumContrast
            || !Number.isFinite(exception.actual) || exception.actual < 1 || exception.actual >= exception.minimum
            || exception.actual !== result.textContrast) throw new Error("Text contrast exception is outside the exact accepted Button label scope");
          exceptionCandidates.push({ recipeId: recipe.id, theme, parentId: parent, part: scope.part, ...exception });
        }
      }
      catch (error) { failures.push(`${recipe.id} ${theme} ${parent}: ${error.message}`); }
    }
  }
  if (exceptionCandidates.length) {
    try {
      const status = parseYamlSubset(readFileSync(join(root, "status/current-phase.yaml"), "utf8"));
      validateTokenFoundationsV1Phase(status);
      if (!status.tokenRefinements?.buttonTokenMigration?.contrastException) throw new Error("Missing the explicit user decision");
      acceptedTextContrastExceptions.push(...exceptionCandidates);
    } catch (error) { failures.push(`Button text contrast exception authorization is invalid: ${error.message}`); }
  }
  try { failures.push(...generateTokenFoundations({ root, check: true }).map((path) => `Stale Token output: ${path}`)); }
  catch (error) { failures.push(`Token outputs cannot be checked: ${error.message}`); }
  const files = sourceFiles(root, consumerDirectory);
  for (const entry of [...outputs.colorConsumers, ...outputs.displayConsumers]) if (!files.includes(entry.filePath)) failures.push(`Missing consumer source: ${entry.filePath}`);
  for (const filePath of files) {
    const source = readFileSync(join(root, filePath), "utf8");
    if (!filePath.endsWith(".css")) failures.push(...validateTokenConsumerSource({ filePath, source, outputs, root }));
    else failures.push(...validateTokenConsumerCss({ filePath, source }));
  }
  const registeredRecipePaths = new Set([...outputs.colorRecipeConsumers, ...outputs.colorCssConsumers].map((entry) => entry.filePath));
  for (const filePath of registeredRecipePaths) if (!existsSync(join(root, filePath))) failures.push(`Missing consumer source: ${filePath}`);
  for (const filePath of [...sourceFiles(root, "apps"), ...sourceFiles(root, "packages/ui/src")]) {
    if (filePath.startsWith(consumerDirectory)) continue;
    const source = readFileSync(join(root, filePath), "utf8");
    failures.push(...validateButtonAliasSource(source, buttonBridge, outputs).map((failure) => `${filePath}: ${failure}`));
    if (registeredRecipePaths.has(filePath)) failures.push(...validateRegisteredRecipeColors({ filePath, source, outputs, root, pendingContrastFindings, pendingEligibilityFindings }));
    else if (categorySource.test(source)) failures.push(`Category/local colors require registered Token consumer metadata: ${filePath}`);
    if (/(?:bg|text)-rain-swatch-|\.display(?:Foreground)?ClassName\b/.test(source) || outputs.displayConsumers.some((entry) => entry.className && source.includes(entry.className))) failures.push(`Display-only colors cannot be consumed outside the registered documentation scope: ${filePath}`);
  }
  let phase = {};
  try { phase = parseYamlSubset(readFileSync(join(root, "status/current-phase.yaml"), "utf8")); }
  catch (error) { failures.push(`Token phase authorization cannot be checked: ${error.message}`); }
  for (const [label, prefix, review, authorized] of [
    ["QuestionNumber", "question-number-", phase.componentRefinements?.questionNumber, hasQuestionNumberRefinementAuthorization(phase)],
    ["OptionButton content", "option-button-content-", phase.componentRefinements?.optionButton?.contentRefinement, hasOptionButtonContentRefinementAuthorization(phase)],
  ]) {
    const acceptance = review?.contrastAcceptance;
    if (!acceptance) continue;
    const findings = pendingContrastFindings.filter((entry) => entry.recipeId.startsWith(prefix));
    const fingerprint = createHash("sha256").update(JSON.stringify(findings.map(({ status, acceptedException, ...finding }) => JSON.stringify(finding)).sort())).digest("hex");
    if (!authorized || findings.length !== acceptance.findingCount || fingerprint !== acceptance.findingsSha256) {
      failures.push(`${label} accepted contrast exceptions must match the exact user-reviewed measurements`);
      continue;
    }
    acceptedComponentContrastExceptions.push(...findings.map((entry) => ({ ...entry,
      status: "user-accepted-exception", acceptedException: true,
      unroundedActual: measureColorContrast(resolveColor(entry.tokenId, entry.theme), resolveColorSurface(entry.parentSurfaceId, entry.theme, entry.parentBackgroundId ?? undefined)),
      decisionSource: acceptance.decisionSource, acceptanceEvidence: acceptance.evidence,
    })));
    for (let index = pendingContrastFindings.length - 1; index >= 0; index--) {
      if (pendingContrastFindings[index].recipeId.startsWith(prefix)) pendingContrastFindings.splice(index, 1);
    }
  }
  if (pendingContrastFindings.length) {
    if (pendingContrastFindings.some((entry) => entry.recipeId.startsWith("question-number-"))) {
      const review = phase.componentRefinements?.questionNumber;
      if (review?.independentReview !== "findings" || review?.implementation === "completed") failures.push("QuestionNumber contrast findings remain pending: independentReview must stay findings and implementation must not claim completed");
    }
    if (pendingContrastFindings.some((entry) => entry.recipeId.startsWith("option-button-content-"))) {
      const review = phase.componentRefinements?.optionButton?.contentRefinement;
      if (review?.independentReview !== "findings" || review?.implementation === "completed") failures.push("OptionButton content contrast findings remain pending: its separate independentReview must stay findings and implementation must not claim completed");
    }
  }
  if (pendingContrastFindings.some((entry) => entry.recipeId.startsWith("input-")) || pendingEligibilityFindings.length) {
    const review = phase.componentRefinements?.input;
    if (review?.independentReview !== "findings" || review?.implementation === "completed") failures.push("Input color findings remain pending: independentReview must stay findings and implementation must not claim completed");
  }
  if (pendingContrastFindings.some((entry) => entry.recipeId.startsWith("tag-"))) {
    const review = phase.componentRefinements?.tag;
    if (!hasTagRefinementAuthorization(phase) || review?.independentReview !== "findings" || review?.implementation === "completed" || review?.contrastAcceptance !== "not-granted") failures.push("Tag source contrast findings remain pending: keep implementation in progress, independentReview findings and no accepted exception");
  }
  return { failures: [...new Set(failures)], consumerFiles: files.length + registeredRecipePaths.size, acceptedTextContrastExceptions, acceptedComponentContrastExceptions, pendingContrastFindings, pendingEligibilityFindings };
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const result = verifyTokenFoundations();
  for (const [label, prefix] of [["QuestionNumber", "question-number-"], ["OptionButton content", "option-button-content-"], ["Input", "input-"], ["Tag", "tag-"]]) {
    const count = result.pendingContrastFindings.filter((entry) => entry.recipeId.startsWith(prefix)).length;
    if (count) console.log(`${label} contrast review remains pending: ${count} declared foreground/boundary combinations below minimum; these are findings, not accepted exceptions or readability passes.`);
    const accepted = result.acceptedComponentContrastExceptions.filter((entry) => entry.recipeId.startsWith(prefix)).length;
    if (accepted) console.log(`${label}: ${accepted} user-accepted contrast exceptions retain their measured ratios and original thresholds; these are not readability passes.`);
  }
  if (result.pendingEligibilityFindings.length) console.log(`Input color-family eligibility remains pending: ${result.pendingEligibilityFindings.length} declared pairings; contrast measurements do not establish eligibility and no exception was accepted.`);
  for (const exception of result.acceptedTextContrastExceptions) {
    console.log(`User-accepted text contrast exception: ${exception.recipeId} ${exception.theme} ${exception.parentId} ${exception.part}: ${exception.actual.toFixed(3)} < ${exception.minimum} (${exception.decisionSource}).`);
  }
  if (result.failures.length) { console.error(result.failures.join("\n")); process.exitCode = 1; }
  else console.log(`Token Foundations verified: generated facts and ${result.consumerFiles} consumer files; ${result.acceptedTextContrastExceptions.length} user-accepted text contrast exceptions${result.acceptedTextContrastExceptions.length ? " remain below 4.5:1 (not readability passes)" : ""}.`);
}
