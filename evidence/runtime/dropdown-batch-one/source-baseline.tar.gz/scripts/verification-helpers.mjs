import { createHash } from "node:crypto";

function yamlError(line, message) {
  const location = line ? ` at line ${line.number}` : "";
  return new Error(`Invalid YAML subset${location}: ${message}`);
}

function parseYamlScalar(value, line) {
  if (value === "[]") {
    return [];
  }
  if (value === "{}") {
    return {};
  }
  if (value === "true") {
    return true;
  }
  if (value === "false") {
    return false;
  }
  if (value === "null") {
    return null;
  }
  if (/^-?(?:0|[1-9]\d*)(?:\.\d+)?$/.test(value)) {
    return Number(value);
  }
  if (value.startsWith('"') && value.endsWith('"')) {
    try {
      return JSON.parse(value);
    } catch (error) {
      throw yamlError(line, `invalid quoted scalar (${error.message})`);
    }
  }

  throw yamlError(
    line,
    `unsupported scalar ${JSON.stringify(value)}; registry scalars must be quoted or JSON-like`,
  );
}

function parseYamlPair(content, line) {
  const match = content.match(/^([A-Za-z][A-Za-z0-9_-]*):(?:\s+(.*))?$/);
  if (!match) {
    throw yamlError(line, `expected a mapping pair, received ${JSON.stringify(content)}`);
  }

  return { key: match[1], rawValue: match[2] ?? "" };
}

export function parseYamlSubset(source) {
  const lines = source
    .split(/\r?\n/)
    .map((raw, index) => ({ raw, number: index + 1 }))
    .filter(({ raw }) => raw.trim().length > 0 && !raw.trimStart().startsWith("#"))
    .map((line) => {
      if (line.raw.includes("\t")) {
        throw yamlError(line, "tabs are not allowed for indentation");
      }

      const indent = line.raw.length - line.raw.trimStart().length;
      if (indent % 2 !== 0) {
        throw yamlError(line, "indentation must use multiples of two spaces");
      }

      return { ...line, indent, content: line.raw.slice(indent) };
    });

  if (lines.length === 0) {
    throw yamlError(null, "document is empty");
  }

  function parseMapping(start, indent) {
    const value = {};
    let cursor = start;

    while (cursor < lines.length && lines[cursor].indent === indent) {
      const line = lines[cursor];
      if (line.content.startsWith("-")) {
        break;
      }

      const { key, rawValue } = parseYamlPair(line.content, line);
      if (Object.hasOwn(value, key)) {
        throw yamlError(line, `duplicate key ${key}`);
      }

      cursor += 1;
      if (rawValue.length > 0) {
        value[key] = parseYamlScalar(rawValue, line);
        continue;
      }

      const child = lines[cursor];
      if (!child || child.indent !== indent + 2) {
        throw yamlError(line, `key ${key} must have a value indented by two spaces`);
      }
      const parsed = parseBlock(cursor, indent + 2);
      value[key] = parsed.value;
      cursor = parsed.cursor;
    }

    return { value, cursor };
  }

  function parseSequence(start, indent) {
    const value = [];
    let cursor = start;

    while (cursor < lines.length && lines[cursor].indent === indent) {
      const line = lines[cursor];
      const match = line.content.match(/^-\s+(.*)$/);
      if (!match) {
        break;
      }

      const itemSource = match[1];
      cursor += 1;
      if (/^[A-Za-z][A-Za-z0-9_-]*:/.test(itemSource)) {
        const { key, rawValue } = parseYamlPair(itemSource, line);
        const item = {};

        if (rawValue.length > 0) {
          item[key] = parseYamlScalar(rawValue, line);
        } else {
          const child = lines[cursor];
          if (!child || child.indent !== indent + 2) {
            throw yamlError(line, `key ${key} must have a value indented by two spaces`);
          }
          const parsed = parseBlock(cursor, indent + 2);
          item[key] = parsed.value;
          cursor = parsed.cursor;
        }

        if (cursor < lines.length && lines[cursor].indent === indent + 2) {
          const continuation = parseMapping(cursor, indent + 2);
          for (const [continuationKey, continuationValue] of Object.entries(
            continuation.value,
          )) {
            if (Object.hasOwn(item, continuationKey)) {
              throw yamlError(lines[cursor], `duplicate key ${continuationKey}`);
            }
            item[continuationKey] = continuationValue;
          }
          cursor = continuation.cursor;
        }

        value.push(item);
      } else {
        value.push(parseYamlScalar(itemSource, line));
      }
    }

    return { value, cursor };
  }

  function parseBlock(start, indent) {
    const line = lines[start];
    if (!line || line.indent !== indent) {
      throw yamlError(line, `expected indentation level ${indent}`);
    }

    return line.content.startsWith("-")
      ? parseSequence(start, indent)
      : parseMapping(start, indent);
  }

  if (lines[0].indent !== 0) {
    throw yamlError(lines[0], "top-level content must not be indented");
  }

  const parsed = parseBlock(0, 0);
  if (parsed.cursor !== lines.length) {
    const line = lines[parsed.cursor];
    throw yamlError(line, `unexpected indentation level ${line.indent}`);
  }

  return parsed.value;
}

export function parseStaticArrayExport(source, exportName) {
  function maskCommentsAndStrings() {
    const masked = [...source];
    let index = 0;

    function maskCharacter(position) {
      if (masked[position] !== "\n" && masked[position] !== "\r") {
        masked[position] = " ";
      }
    }

    while (index < source.length) {
      if (source.startsWith("//", index)) {
        while (index < source.length && source[index] !== "\n") {
          maskCharacter(index);
          index += 1;
        }
        continue;
      }
      if (source.startsWith("/*", index)) {
        const start = index;
        while (index < source.length && !source.startsWith("*/", index)) {
          maskCharacter(index);
          index += 1;
        }
        if (index >= source.length) {
          throw new Error(`Unterminated comment at offset ${start}`);
        }
        maskCharacter(index);
        maskCharacter(index + 1);
        index += 2;
        continue;
      }

      const quote = source[index];
      if (quote === '"' || quote === "'" || quote === "`") {
        const start = index;
        maskCharacter(index);
        index += 1;
        let escaped = false;
        while (index < source.length) {
          const character = source[index];
          maskCharacter(index);
          index += 1;
          if (!escaped && character === quote) {
            break;
          }
          escaped = !escaped && character === "\\";
          if (character !== "\\") {
            escaped = false;
          }
        }
        if (source[index - 1] !== quote) {
          throw new Error(`Unterminated string at offset ${start}`);
        }
        continue;
      }
      index += 1;
    }

    return masked.join("");
  }

  const codeOnlySource = maskCommentsAndStrings();
  const escapedName = exportName.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const declaration = new RegExp(
    `export\\s+const\\s+${escapedName}\\b[^=]*=\\s*`,
  ).exec(codeOnlySource);
  if (!declaration) {
    throw new Error(`Missing exported static array ${exportName}`);
  }

  let cursor = declaration.index + declaration[0].length;

  function skipTrivia() {
    while (cursor < source.length) {
      if (/\s/.test(source[cursor])) {
        cursor += 1;
        continue;
      }
      if (source.startsWith("//", cursor)) {
        const newline = source.indexOf("\n", cursor + 2);
        cursor = newline === -1 ? source.length : newline + 1;
        continue;
      }
      if (source.startsWith("/*", cursor)) {
        const end = source.indexOf("*/", cursor + 2);
        if (end === -1) {
          throw new Error("Unterminated comment in static literal export");
        }
        cursor = end + 2;
        continue;
      }
      break;
    }
  }

  function readString() {
    const start = cursor;
    cursor += 1;
    let escaped = false;
    while (cursor < source.length) {
      const character = source[cursor];
      if (!escaped && character === '"') {
        cursor += 1;
        try {
          return JSON.parse(source.slice(start, cursor));
        } catch (error) {
          throw new Error(`Invalid string in static literal: ${error.message}`);
        }
      }
      escaped = !escaped && character === "\\";
      if (character !== "\\") {
        escaped = false;
      }
      cursor += 1;
    }
    throw new Error("Unterminated string in static literal export");
  }

  function readIdentifier() {
    const match = source.slice(cursor).match(/^[A-Za-z_$][A-Za-z0-9_$-]*/);
    if (!match) {
      throw new Error(
        `Expected a static literal identifier near ${JSON.stringify(source.slice(cursor, cursor + 24))}`,
      );
    }
    cursor += match[0].length;
    return match[0];
  }

  function parseValue() {
    skipTrivia();
    const character = source[cursor];
    if (character === '"') {
      return readString();
    }
    if (character === "[") {
      cursor += 1;
      const values = [];
      skipTrivia();
      while (source[cursor] !== "]") {
        values.push(parseValue());
        skipTrivia();
        if (source[cursor] === ",") {
          cursor += 1;
          skipTrivia();
          if (source[cursor] === "]") {
            break;
          }
        } else if (source[cursor] !== "]") {
          throw new Error("Expected comma or closing bracket in static literal array");
        }
      }
      if (source[cursor] !== "]") {
        throw new Error("Unterminated static literal array");
      }
      cursor += 1;
      return values;
    }
    if (character === "{") {
      cursor += 1;
      const value = {};
      skipTrivia();
      while (source[cursor] !== "}") {
        const key = source[cursor] === '"' ? readString() : readIdentifier();
        skipTrivia();
        if (source[cursor] !== ":") {
          throw new Error(`Expected colon after static literal property ${key}`);
        }
        cursor += 1;
        if (Object.hasOwn(value, key)) {
          throw new Error(`Duplicate static literal property ${key}`);
        }
        value[key] = parseValue();
        skipTrivia();
        if (source[cursor] === ",") {
          cursor += 1;
          skipTrivia();
          if (source[cursor] === "}") {
            break;
          }
        } else if (source[cursor] !== "}") {
          throw new Error("Expected comma or closing brace in static literal object");
        }
      }
      if (source[cursor] !== "}") {
        throw new Error("Unterminated static literal object");
      }
      cursor += 1;
      return value;
    }
    if (character === "-" || /\d/.test(character ?? "")) {
      const match = source.slice(cursor).match(/^-?(?:0|[1-9]\d*)(?:\.\d+)?/);
      if (!match) {
        throw new Error("Invalid number in static literal export");
      }
      cursor += match[0].length;
      return Number(match[0]);
    }
    if (/[A-Za-z_$]/.test(character ?? "")) {
      const identifier = readIdentifier();
      if (identifier === "true") return true;
      if (identifier === "false") return false;
      if (identifier === "null") return null;
      throw new Error(`Expected a static literal, received ${identifier}`);
    }

    throw new Error(
      `Expected a static literal near ${JSON.stringify(source.slice(cursor, cursor + 24))}`,
    );
  }

  const value = parseValue();
  if (!Array.isArray(value)) {
    throw new Error(`Export ${exportName} must be a static literal array`);
  }
  return value;
}

export function isDayOneForbiddenDependency(dependency) {
  return (
    dependency === "radix-ui" ||
    dependency.startsWith("@radix-ui/") ||
    dependency === "@base-ui/react" ||
    dependency.startsWith("@base-ui-components/") ||
    dependency === "shadcn" ||
    dependency === "shadcn-ui" ||
    dependency.startsWith("@shadcn/")
  );
}

export function getExpectedDayThreeLifecycle(
  progress,
  automatedVerification,
) {
  const implementationByProgress = {
    "task-4-core-ui-in-progress": "in-progress",
    "task-4-core-ui-completed": "completed",
  };
  const evidenceByVerification = {
    "not-run": "not-run",
    failed: "pnpm-verify-failed",
    passed: "pnpm-verify-and-reuse-audit-passed",
  };
  const implementation = implementationByProgress[progress];
  const automatedVerificationEvidence =
    evidenceByVerification[automatedVerification];

  if (!implementation || !automatedVerificationEvidence) {
    throw new Error(
      `Invalid Day 3 lifecycle outcome: ${progress} / ${automatedVerification}`,
    );
  }
  if (
    progress === "task-4-core-ui-completed" &&
    automatedVerification !== "passed"
  ) {
    throw new Error(
      `Invalid Day 3 lifecycle outcome: completed work requires passed verification`,
    );
  }

  return {
    visualEvidence: "live-reinspected",
    benchmark: "registered",
    implementation,
    implementationScope: "day-3-task-4-core-ui-families",
    automatedVerification,
    automatedVerificationScope: "day-3-task-4-core-ui-families",
    automatedVerificationEvidence,
    humanGate: "not-evaluated",
    figmaEditableMaterial: "not-authorized",
    figmaComponentPublication: "not-authorized",
    packageOrRegistryPublication: "not-authorized",
    businessMigration: "not-authorized",
    localGitCommit: "not-created",
    remoteGit: "not-configured",
  };
}

export const tailwindB2AllowedActions = [
  "只读检查已登记的设计、代码、图标来源与验证证据",
  "创建或修订 B2 架构、计划、治理和状态文档",
  "仅安装 class-variance-authority@0.7.1 与 tailwind-merge@3.6.0 两项直接依赖",
  "建立 Rain Token 到 Tailwind 的映射与受约束组合合同",
  "仅迁移 Button 与 Input Master 的样式实现",
  "建立搜索操作区 Local Recipe 与 Local Fork 隔离试点",
  "创建 B2 Manifest、基线、测试、浏览器证据与决策报告",
  "运行既有质量门、图标验证、类型检查、构建与浏览器验证",
];

export const tailwindB2BlockedActions = [
  "安装其他直接依赖或执行依赖升级",
  "实现 Select、Dialog、Table、Statistic、Layout、Headless 实验或原定 Benchmark 页面",
  "迁移 Tag、Badge、Surface、Card 或图标资产实现",
  "使用 Tailwind 默认视觉体系或未登记的视觉值",
  "批量安装或复制 shadcn 资产",
  "执行 Figma 写入或发布 Figma Component/Variant",
  "创建新的 Git branch 或 worktree",
  "创建本地 Git commit",
  "创建或配置远程仓库、push、PR 或 merge",
  "发布包、新增 B2 源码 Registry 或执行业务迁移",
];

export const tailwindB2Checkpoint = {
  id: "tailwind-b2-composition-contract",
  label: "Tailwind B2 组合合同与局部隔离试点",
  status: "authorized",
  decisionSource: "explicit-user-authorization-tailwind-b2-composition-contract",
  requiredEvidence: [
    "B2 设计与实施计划已确认",
    "Day 3 与图标库的既有实现、验证和独立 Human Gate 已保留",
    "试点仅限 Input、Button 与搜索操作区",
  ],
  unlocks: [
    "Rain Token 到 Tailwind 的受约束映射与组合合同",
    "仅 Input、Button Master 迁移及搜索操作区 Local Recipe / Local Fork 试点",
    "仅 class-variance-authority@0.7.1 与 tailwind-merge@3.6.0 两项直接依赖",
    "B2 基线、隔离验证与独立 Human Gate 证据",
  ],
};

const tailwindB2PriorCheckpoints = [
  {
    id: "day-1-runtime-start", label: "Day 1 运行骨架启动", status: "authorized",
    requiredEvidence: [
      "14 个 Visual Evidence 均完成现场复核；安全截图入库，含身份字段的截图按隐私规则不入库",
      "四个 Benchmark 的来源映射完成复核",
      "资产审计报告记录保留、重设、不继承和未知项",
      "Day 1–Day 10 实施计划通过文档与引用检查",
    ],
    unlocks: ["依赖安装", "最小运行骨架", "测试基础设施"],
  },
  {
    id: "day-2-foundations-start", label: "Day 2 Foundations 启动", status: "authorized",
    decisionSource: "用户确认 Day 1 页面无问题并明确要求开始下一批任务",
    requiredEvidence: [
      "Day 1 空壳、质量门与证据入口已完成自动验证",
      "Task 3 的范围、工作模式、验证方法与未验证字体假设已声明",
    ],
    unlocks: [
      "Foundations token 合同", "Typography、Density、Radius、Shadow、Focus 与 Motion 最小规则",
      "Foundations 展示夹具与 Day 2 运行证据",
    ],
  },
  {
    id: "day-3-core-ui-start", label: "Day 3 Core UI 启动", status: "authorized",
    decisionSource: "用户明确要求继续进入 Rain Next 组件实现",
    requiredEvidence: [
      "Day 2 Foundations 与 Day 2.1 Focus/颜色修正已完成自动验证",
      "Rain Classic → Rain Next 复用审核 CP3 已接受", "Task 4 设计边界已按最终复用矩阵修订",
    ],
    unlocks: [
      "Button、Input、Tag/Badge 与 Surface/Card 基础 UI 家族",
      "Core UI 状态矩阵、说明页与修改边界", "Day 3 单元、交互、浏览器测试与运行证据",
    ],
  },
];

export function getExpectedTailwindB2Lifecycle(progress, automatedVerification) {
  const implementationByProgress = {
    "tailwind-b2-pilot-in-progress": "in-progress",
    "tailwind-b2-pilot-completed": "completed",
  };
  const evidenceByVerification = {
    "not-run": "not-run",
    failed: "pnpm-verify-failed",
    passed: "pnpm-verify-tailwind-b2-and-verify-and-reuse-audit-passed",
  };
  const implementation = implementationByProgress[progress];
  const automatedVerificationEvidence = evidenceByVerification[automatedVerification];
  if (!Object.hasOwn(implementationByProgress, progress) || !Object.hasOwn(evidenceByVerification, automatedVerification)
    || (implementation === "completed" && automatedVerification !== "passed")) {
    throw new Error(`Invalid B2 lifecycle outcome: ${progress} / ${automatedVerification}`);
  }
  return {
    visualEvidence: "live-reinspected", benchmark: "registered", implementation,
    implementationScope: "input-button-search-operation-pilot",
    automatedVerification, automatedVerificationScope: "input-button-search-operation-pilot",
    automatedVerificationEvidence,
    humanGate: implementation === "completed" ? "awaiting_human" : "not-evaluated",
    figmaEditableMaterial: "not-authorized", figmaComponentPublication: "not-authorized",
    packageOrRegistryPublication: "not-authorized", businessMigration: "not-authorized",
    localGitCommit: "not-created", remoteGit: "not-configured",
  };
}

function exactRecord(actual, expected) {
  return actual && typeof actual === "object" && !Array.isArray(actual)
    && Object.keys(actual).length === Object.keys(expected).length
    && Object.entries(expected).every(([key, value]) => JSON.stringify(actual[key]) === JSON.stringify(value));
}

export const tokenFoundationsV1AllowedActions = [
  "只读核对最新 Token 设计、Rain Classic 来源、现有消费者与冻结基线",
  "建立第 0/1 批独立阶段、实施计划、ADR、精确合同与验证证据",
  "增量建设 Light Color Registry、Typography、Line Thickness、Radius 与 Spacing 基础合同",
  "建立单源生成输出、受控 Tailwind 桥接、AI 使用文档与静态校验",
  "建立独立 Token Foundations 演示路由、对照样例与第 0/1 批测试",
  "运行专项检查及既有完整质量门、浏览器验证和独立技术审阅",
];

export const tokenFoundationsV1BlockedActions = [
  "迁移或改变既有组件视觉数值、状态、行为与独立 Human Gate",
  "实现新的公共 UI、Layout、Recipe 家族或原定 Benchmark 页面",
  "执行第 2 批及后续组件迁移、Size/Density 配方建设或 Dark Mode 实现",
  "修改 Rain Classic、写入或发布 Figma 资产",
  "安装新依赖、升级依赖或批量复制 shadcn 资产",
  "创建 Git branch、worktree、commit、远程仓库、push、PR 或 merge",
  "发布包、源码 Registry 或执行业务迁移",
];

export const tokenFoundationsV1Checkpoint = {
  id: "token-foundations-v1", label: "Token Foundations V1 第 0/1 批", status: "authorized",
  decisionSource: "explicit-user-authorization-token-foundations-v1-batch-0-1",
  requiredEvidence: [
    "最新有效 Token 文档及依赖顺序已审阅，用户明确授权开始第 0/1 批",
    "原运行文件与 B2 完整阶段状态已冻结；旧验收与生命周期分别保留",
    "新增能力通过精确文件、权限、生成来源与独立验证范围登记",
  ],
  unlocks: [
    "Light 颜色登记与 Typography、Line、Radius、Spacing 基础合同",
    "受控桥接、单源生成、静态校验与独立演示入口",
    "第 0/1 批专项及回归证据，不授权既有组件迁移或后续批次",
  ],
};

export const tokenFoundationsV1Files = {
  foundations: [
    "packages/foundations/src/color-registry.ts", "packages/foundations/src/color-registry.test.ts",
    "packages/foundations/src/typography-contract.ts", "packages/foundations/src/typography-contract.test.ts",
    "packages/foundations/src/line-foundation.test.ts",
  ],
  application: [
    "token-foundations-page.tsx", "token-foundations-page.test.tsx", "token-foundations.css",
    "color-panel.tsx", "color-panel.test.tsx", "color-pairing-preview.tsx", "typography-panel.tsx", "typography-panel.test.tsx",
    "geometry-panel.tsx", "token-classes.generated.ts",
  ].map((name) => `apps/playground/src/docs/token-foundations/${name}`),
  workspace: [
    "scripts/token-foundation-outputs.mjs", "scripts/generate-token-foundations.mjs",
    "scripts/verify-token-foundations.mjs", "scripts/verify-token-foundations.test.ts",
    "tests/e2e/token-foundations.spec.ts",
  ],
  documents: [
    "docs/adr/0003-size-and-density-responsibilities.md", "docs/adr/0004-token-foundations-v1.md", "docs/plans/2026-09-05-token-foundations-v1-implementation.md",
    "docs/plans/2026-09-05-size-density-first-recipes.md", "docs/ai/token-selection.md",
    "docs/plans/2026-09-06-color-family-supplement-design.md", "docs/plans/2026-09-06-color-dark-theme.md",
    "manifests/contracts/token-foundations-v1.json",
  ],
  evidence: [
    "pre-token-runtime.tar.gz", "pre-token-runtime.json", "verification.md", "line.png",
    "typography.png", "colors.png", "geometry.png", "baseline-red.log", "final-verify.log", "independent-review.md",
  ].map((name) => `evidence/runtime/token-foundations-v1/${name}`),
};

export function getExpectedTokenFoundationsV1Lifecycle(progress, automatedVerification) {
  const implementations = {
    "token-foundations-v1-batch-0-1-in-progress": "in-progress",
    "token-foundations-v1-batch-0-1-completed": "completed",
  };
  if (!Object.hasOwn(implementations, progress)
    || !["not-run", "failed", "passed"].includes(automatedVerification)
    || (implementations[progress] === "completed" && automatedVerification !== "passed")) {
    throw new Error(`Invalid Token Foundations V1 phase lifecycle: ${progress} / ${automatedVerification}`);
  }
  return {
    visualEvidence: "live-reinspected", benchmark: "registered", implementation: implementations[progress],
    implementationScope: "token-foundations-v1-batch-0-1", automatedVerification,
    automatedVerificationScope: "token-foundations-v1-batch-0-1",
    automatedVerificationEvidence: automatedVerification === "passed" ? "pnpm-verify-tokens-and-pnpm-verify-passed" : automatedVerification === "failed" ? "pnpm-verify-failed" : "not-run",
    humanGate: implementations[progress] === "completed" ? "awaiting_human" : "not-evaluated",
    figmaEditableMaterial: "not-authorized", figmaComponentPublication: "not-authorized",
    packageOrRegistryPublication: "not-authorized", businessMigration: "not-authorized",
    localGitCommit: "not-created", remoteGit: "not-configured",
  };
}

export const inputRefinementFiles = {
  foundations: ["packages/foundations/src/input-token-contract.ts", "packages/foundations/src/input-token-contract.test.ts"],
  ui: [
    ...["input.tsx", "input.utils.ts", "input.test.tsx", "input.utils.test.ts", "input.styles.ts", "input-field.test.tsx"].map((name) => `packages/ui/src/input/${name}`),
    ...["form-item", "search-input"].map((name) => `packages/ui/src/input/${name}.tsx`),
  ],
  application: ["input-page.tsx", "input-page.css", "input-page.test.tsx"].map((name) => `apps/playground/src/docs/components/${name}`),
  workspace: [
    "scripts/input-governance.test.ts", "scripts/input-color-consumers.test.ts", "tests/e2e/input.spec.ts",
    "tests/e2e/core-ui.spec.ts", "tests/e2e/foundations.spec.ts", "packages/foundations/src/index.ts",
    "packages/ui/src/index.ts", "packages/ui/src/styles.css", "apps/playground/src/app.tsx",
    "apps/playground/src/styles.css", "apps/playground/src/routes/route-registry.ts", "apps/playground/src/docs/components/core-ui-page.tsx",
    "scripts/token-foundation-outputs.mjs", "scripts/generate-token-foundations.mjs", "scripts/verification-helpers.mjs", "scripts/verification-helpers.test.ts",
    "scripts/verify-boundaries.mjs", "scripts/verify-tailwind-b2.mjs", "scripts/verify-tailwind-b2.test.ts", "scripts/verify-token-foundations.mjs",
    "manifests/contracts/tailwind-b2.yaml", "status/current-phase.yaml",
  ],
  documents: ["docs/plans/2026-09-08-input-design.md", "docs/plans/2026-09-08-input-implementation.md", "manifests/ui/input.yaml", "manifests/ui/form-item.yaml", "manifests/ui/search-input.yaml"],
  evidence: ["verification.md", "light.png", "dark.png", "compact.png", "color-findings.json", "inline-text-button-colors.json"].map((name) => `evidence/runtime/input/${name}`),
};

export const tagRefinementFiles = {
  foundations: ["packages/foundations/src/tag-token-contract.ts", "packages/foundations/src/tag-token-contract.test.ts"],
  ui: ["tag.styles.ts", "link-tag.tsx", "checkable-tag.tsx", "tag-interactions.test.tsx"].map((name) => `packages/ui/src/tag/${name}`),
  application: ["tag-page.tsx", "tag-page.css", "tag-page.test.tsx"].map((name) => `apps/playground/src/docs/components/${name}`),
  workspace: ["scripts/tag-governance.test.ts", "scripts/tag-color-consumers.test.ts", "tests/e2e/tag.spec.ts", "packages/ui/src/tag/tag.tsx", "packages/ui/src/tag/tag-badge.test.tsx"],
  documents: ["docs/plans/2026-09-08-tag-design.md", "docs/plans/2026-09-09-tag-batch-one-implementation.md", "registry/tag.json", ...["tag", "link-tag", "checkable-tag", "checkable-tag-group"].map((name) => `manifests/ui/${name}.yaml`)],
  evidence: ["source-colors.json", "verification.md", "independent-review.md", "light.png", "dark.png", "compact.png", "color-findings.json", "paint-samples.json"].map((name) => `evidence/runtime/tag-batch-one/${name}`),
};

export function hasTagRefinementAuthorization(status) {
  const refinement = status?.componentRefinements?.tag;
  const accepted = refinement?.humanGate === "accepted";
  return Boolean(refinement && status?.currentPhase?.id === "token-foundations-v1"
    && ["awaiting_human", "accepted"].includes(refinement.humanGate)
    && (!accepted || (refinement.automatedVerification === "passed"
      && ["findings", "passed"].includes(refinement.independentReview)
      && exactRecord(refinement.humanGateDecision, {
        acceptedAt: "2026-09-09", decisionSource: "explicit-user-confirmation",
        userStatement: "没问题。完成本轮视觉校验。推进下一步",
        scope: "tag-batch-one-runtime-visual-only", evidence: "../evidence/runtime/tag-batch-one/verification.md",
      })))
    && ["in-progress", "completed"].includes(refinement.implementation)
    && ["not-run", "failed", "passed"].includes(refinement.automatedVerification)
    && ["not-run", "findings", "passed"].includes(refinement.independentReview)
    && (refinement.implementation !== "completed" || (refinement.automatedVerification === "passed" && refinement.independentReview === "passed"))
    && exactRecord(refinement, {
      authorization: "authorized", authorizedAt: "2026-09-09",
      decisionSource: "explicit-user-enter-tag-batch-one-implementation", userStatement: "进入下一步",
      scope: "tag-batch-one-full-palette-sizes-dismiss-link-and-selection",
      plan: "../docs/plans/2026-09-09-tag-batch-one-implementation.md", design: "../docs/plans/2026-09-08-tag-design.md",
      visualBaseline: "accepted-preview-visual-only", implementation: refinement.implementation,
      automatedVerification: refinement.automatedVerification, independentReview: refinement.independentReview,
      humanGate: refinement.humanGate, ...(accepted ? { humanGateDecision: refinement.humanGateDecision } : {}), contrastAcceptance: "not-granted",
      doesNotAuthorize: ["tag-domain-shapes-or-tag-select-and-creation", "other-components-or-global-visual-rules", "new-dependencies-or-unreviewed-contrast-exceptions", "figma-publication-business-migration-or-git"],
    }));
}

export function hasInputRefinementAuthorization(status) {
  const refinement = status?.componentRefinements?.input;
  if (!refinement) return false;
  return status?.currentPhase?.id === "token-foundations-v1"
    && ["in-progress", "completed"].includes(refinement.implementation)
    && ["not-run", "failed", "passed"].includes(refinement.automatedVerification)
    && ["not-run", "findings", "passed"].includes(refinement.independentReview)
    && refinement.humanGate === "awaiting_human"
    && (refinement.implementation !== "completed" || (refinement.automatedVerification === "passed" && refinement.independentReview === "passed"))
    && exactRecord(refinement, {
      authorization: "authorized", authorizedAt: "2026-09-08",
      decisionSource: "explicit-user-start-input-construction", userStatement: "开始建设该组件",
      scope: "input-search-input-form-item-token-recipes-and-review",
      plan: "../docs/plans/2026-09-08-input-implementation.md", design: "../docs/plans/2026-09-08-input-design.md",
      implementation: refinement.implementation, automatedVerification: refinement.automatedVerification,
      independentReview: refinement.independentReview, humanGate: refinement.humanGate,
      ...(refinement.visualRevision ? { visualRevision: {
        authorization: "authorized", authorizedAt: "2026-09-08",
        decisionSource: "explicit-user-start-confirmed-input-visual-revision", userStatement: "开始调整代码",
        scope: "input-clear-order-spacing-focus-status-and-text-color-revision", contrastAcceptance: "not-granted",
      } } : {}),
      doesNotAuthorize: ["other-components-or-public-control-height-scale", "new-colors-or-dependencies", "figma-publication-business-migration-or-git"],
    });
}

export const iconButtonRefinementFiles = {
  foundations: ["packages/foundations/src/icon-size-contract.ts", "packages/foundations/src/icon-size-contract.test.ts"],
  ui: ["icon-button.tsx", "icon-button.styles.ts", "icon-button.test.tsx"].map((name) => `packages/ui/src/icon-button/${name}`),
  application: ["icon-button-page.tsx", "icon-button-page.css", "icon-button-page.test.tsx"].map((name) => `apps/playground/src/docs/components/${name}`),
  workspace: ["tests/e2e/icon-button.spec.ts", "scripts/icon-size-outputs.test.ts", "scripts/icon-button-color-consumers.test.ts"],
  documents: ["docs/plans/2026-09-07-icon-button-implementation.md", "manifests/ui/icon-button.yaml", "registry/icon-button.json"],
  evidence: ["verification.md", "light.png", "dark.png", "compact.png"].map((name) => `evidence/runtime/icon-button/${name}`),
};

export function hasIconButtonRefinementAuthorization(status) {
  const refinement = status?.componentRefinements?.iconButton;
  if (!refinement) return false;
  return status?.currentPhase?.id === "token-foundations-v1"
    && ["in-progress", "completed"].includes(refinement.implementation)
    && ["not-run", "failed", "passed"].includes(refinement.automatedVerification)
    && ["not-run", "findings", "passed"].includes(refinement.independentReview)
    && ["awaiting_human", "accepted"].includes(refinement.humanGate)
    && (refinement.humanGate !== "accepted" || refinement.implementation === "completed")
    && (refinement.implementation !== "completed"
      || (refinement.automatedVerification === "passed" && refinement.independentReview === "passed"))
    && exactRecord(refinement, {
      authorization: "authorized",
      authorizedAt: "2026-09-07",
      decisionSource: "explicit-user-start-implementation-after-icon-button-design-confirmation",
      userStatement: "开始实现",
      scope: "public-icon-size-foundations-icon-button-and-review-verification",
      plan: "../docs/plans/2026-09-07-icon-button-implementation.md",
      designConfirmation: "accepted",
      implementation: refinement.implementation,
      automatedVerification: refinement.automatedVerification,
      independentReview: refinement.independentReview,
      humanGate: refinement.humanGate,
      ...(refinement.humanGate === "accepted" ? {
        humanGateDecision: {
          acceptedAt: "2026-09-07", decisionSource: "explicit-user-confirmation", userStatement: "确认视觉验收",
          scope: "icon-button-visual-only", evidence: "../evidence/runtime/icon-button/verification.md",
        },
      } : {}),
      doesNotAuthorize: [
        "existing-component-migration-or-visual-changes",
        "tooltip-or-headless-library-selection",
        "new-dependencies",
        "figma-publication-business-migration-or-git",
      ],
    });
}

export const questionOptionSizeReviewFiles = {
  application: [
    "apps/playground/question-option-sizes.html",
    ...["main.tsx", "review.css", "manifest.json"].map((name) => `apps/playground/src/experiments/question-option-sizes/${name}`),
  ],
  workspace: ["tests/e2e/question-option-sizes.spec.ts"],
};

export const questionOptionSizeRefinementFiles = {
  ui: ["packages/ui/src/recipes/question-option-size.ts"],
  documents: ["docs/plans/2026-09-08-question-option-size-implementation.md"],
};

export function hasQuestionOptionSizeRefinementAuthorization(status) {
  const refinement = status?.componentRefinements?.questionOptionSizes;
  return Boolean(refinement)
    && hasQuestionNumberRefinementAuthorization(status) && hasOptionButtonContentRefinementAuthorization(status)
    && ["in-progress", "completed"].includes(refinement.implementation)
    && ["not-run", "failed", "passed"].includes(refinement.automatedVerification)
    && ["not-run", "findings", "passed"].includes(refinement.independentReview)
    && ["awaiting_human", "accepted"].includes(refinement.humanGate)
    && (refinement.humanGate !== "accepted" || refinement.implementation === "completed")
    && (refinement.implementation !== "completed" || (refinement.automatedVerification === "passed" && refinement.independentReview === "passed"))
    && exactRecord(refinement, {
      authorization: "authorized", authorizedAt: "2026-09-08",
      decisionSource: "explicit-user-continue-after-six-size-visual-acceptance", userStatement: "继续推进",
      scope: "question-option-six-public-sizes-default-28-and-density-spacing",
      plan: "../docs/plans/2026-09-08-question-option-size-implementation.md", designConfirmation: "accepted",
      implementation: refinement.implementation, automatedVerification: refinement.automatedVerification,
      independentReview: refinement.independentReview, humanGate: refinement.humanGate,
      ...(refinement.humanGate === "accepted" ? {
        humanGateDecision: {
          acceptedAt: "2026-09-08", decisionSource: "explicit-user-confirmation",
          userStatement: "视觉确认，", scope: "question-option-six-public-sizes-visual-only",
          evidence: "../docs/plans/2026-09-08-question-option-size-implementation.md",
        },
      } : {}),
      doesNotAuthorize: ["top-right-feedback-or-new-business-behavior", "new-tokens-dependencies-or-contrast-exceptions", "other-component-gates-or-publication-business-migration-git"],
    });
}

export function hasQuestionOptionSizeReviewAuthorization(status) {
  return status?.currentPhase?.id === "token-foundations-v1"
    && Boolean(status.localExperiments)
    && exactRecord(status.localExperiments, {
      questionOptionSizeReview: {
        authorization: "authorized", authorizedAt: "2026-09-08",
        decisionSource: "explicit-user-continue-size-comparison", userStatement: "继续推进",
        scope: "question-option-six-size-local-review-only", assetIdentity: "local-experiment",
        plan: "../docs/plans/2026-09-08-question-option-size-design.md",
        manifest: "../apps/playground/src/experiments/question-option-sizes/manifest.json",
      },
    });
}

export const questionNumberRefinementFiles = {
  foundations: [],
  ui: ["question-number.tsx", "question-number.styles.ts", "question-number.test.tsx"].map((name) => `packages/ui/src/question-number/${name}`),
  application: ["question-number-page.tsx", "question-number-page.css", "question-number-page.test.tsx"].map((name) => `apps/playground/src/docs/components/${name}`),
  workspace: ["tests/e2e/question-number.spec.ts"],
  documents: ["docs/plans/2026-09-08-question-number-implementation.md", "manifests/ui/question-number.yaml", "registry/question-number.json"],
  evidence: ["verification.md", "light.png", "dark.png", "compact.png"].map((name) => `evidence/runtime/question-number/${name}`),
};

export const textButtonVisualAcceptance = Object.freeze({
  acceptedAt: "2026-09-08", decisionSource: "explicit-user-confirmation",
  userStatement: "TextButton：最新配方的视觉验收确认", scope: "text-button-current-token-recipe-visual-only",
  evidence: "../docs/verification/2026-09-03-text-button-implementation.md",
});

export const questionNumberContrastAcceptance = Object.freeze({
  acceptedAt: "2026-09-08", decisionSource: "explicit-user-component-acceptance-after-contrast-review",
  userStatement: "题号按钮：完成验收。题号右上角反馈方案暂时先不建设了。",
  scope: "question-number-declared-contrast-combinations-only", findingCount: 93,
  findingsSha256: "df163ed1e0011b628f0549421c27575929209f3cd5012994b9d6f69e2044ade8",
  outcome: "report-actual-contrast-user-accepted", evidence: "../evidence/runtime/question-number/verification.md",
});

export const optionButtonContentContrastAcceptance = Object.freeze({
  acceptedAt: "2026-09-08", decisionSource: "explicit-user-contrast-acceptance",
  userStatement: "选项按钮：基础选择和六档尺寸已验收；结果、只读、判断、图文已实现，对比度完成验收。",
  scope: "option-button-content-declared-contrast-combinations-only", findingCount: 9,
  findingsSha256: "93eec9a4677e563320da4ffc5ded2111baadd2c25c7d3556709a8c39548a2d33",
  outcome: "report-actual-contrast-user-accepted", evidence: "../evidence/runtime/option-button-content/verification.md",
});

export function hasQuestionNumberRefinementAuthorization(status) {
  const refinement = status?.componentRefinements?.questionNumber;
  if (!refinement) return false;
  return status?.currentPhase?.id === "token-foundations-v1"
    && ["in-progress", "completed"].includes(refinement.implementation)
    && ["not-run", "failed", "passed"].includes(refinement.automatedVerification)
    && ["not-run", "findings", "passed"].includes(refinement.independentReview)
    && ["not-evaluated", "awaiting_human", "accepted"].includes(refinement.humanGate)
    && (refinement.implementation !== "completed"
      || (refinement.automatedVerification === "passed" && refinement.independentReview === "passed"))
    && exactRecord(refinement, {
      authorization: "authorized", authorizedAt: "2026-09-08",
      decisionSource: "explicit-user-continue-after-question-number-reference-confirmation",
      userStatement: "继续", scope: "question-number-32-bottom-feedback-and-two-grading-icons",
      plan: "../docs/plans/2026-09-08-question-number-implementation.md", designConfirmation: "accepted",
      implementation: refinement.implementation, automatedVerification: refinement.automatedVerification,
      independentReview: refinement.independentReview, humanGate: refinement.humanGate,
      ...(refinement.humanGate === "accepted" ? {
        humanGateDecision: {
          acceptedAt: "2026-09-08", decisionSource: "explicit-user-confirmation",
          userStatement: "首版32px的题号按钮，已可以视觉验收", scope: "question-number-32-visual-only",
          evidence: "../evidence/runtime/question-number/verification.md",
        },
      } : {}),
      ...(refinement.contrastAcceptance ? { contrastAcceptance: questionNumberContrastAcceptance } : {}),
      doesNotAuthorize: [
        "other-sizes-top-right-markers-or-option-button", "existing-component-migration-or-visual-changes",
        "tooltip-or-new-dependencies", "figma-publication-business-migration-or-git",
      ],
    });
}

export const optionButtonRefinementFiles = {
  foundations: [],
  ui: ["option-button.tsx", "option-button.styles.ts", "option-button.test.tsx"].map((name) => `packages/ui/src/option-button/${name}`),
  application: ["option-button-page.tsx", "option-button-page.css", "option-button-page.test.tsx"].map((name) => `apps/playground/src/docs/components/${name}`),
  workspace: ["tests/e2e/option-button.spec.ts"],
  documents: ["docs/plans/2026-09-08-option-button-implementation.md", "manifests/ui/option-button.yaml", "registry/option-button.json"],
  evidence: ["verification.md", "light.png", "dark.png", "compact.png"].map((name) => `evidence/runtime/option-button/${name}`),
};

export const optionButtonContentRefinementFiles = {
  application: ["option-chart-linear.svg", "option-chart-parabola.svg"].map((name) => `apps/playground/src/docs/components/${name}`),
  documents: ["docs/plans/2026-09-08-option-button-content-implementation.md"],
  evidence: ["verification.md", "light.png", "dark.png", "compact.png"].map((name) => `evidence/runtime/option-button-content/${name}`),
};

function validOptionButtonContentRefinement(refinement) {
  return Boolean(refinement)
    && ["in-progress", "completed"].includes(refinement.implementation)
    && ["not-run", "failed", "passed"].includes(refinement.automatedVerification)
    && ["not-run", "findings", "passed"].includes(refinement.independentReview)
    && ["not-evaluated", "awaiting_human", "accepted"].includes(refinement.humanGate)
    && (refinement.humanGate !== "accepted" || refinement.implementation === "completed")
    && (refinement.implementation !== "completed" || (refinement.automatedVerification === "passed" && refinement.independentReview === "passed"))
    && exactRecord(refinement, {
      authorization: "authorized", authorizedAt: "2026-09-08",
      decisionSource: "explicit-user-continue-after-option-selection-visual-confirmation",
      userStatement: "视觉没问题。推进下一步", scope: "option-button-32-results-readonly-judgment-media",
      plan: "../docs/plans/2026-09-08-option-button-content-implementation.md", designConfirmation: "accepted",
      implementation: refinement.implementation, automatedVerification: refinement.automatedVerification,
      independentReview: refinement.independentReview, humanGate: refinement.humanGate,
      ...(refinement.humanGate === "accepted" ? {
        humanGateDecision: {
          acceptedAt: "2026-09-08", decisionSource: "explicit-user-component-and-contrast-confirmation",
          userStatement: "选项按钮：基础选择和六档尺寸已验收；结果、只读、判断、图文已实现，对比度完成验收。",
          scope: "option-button-results-readonly-judgment-media-and-contrast",
          evidence: "../evidence/runtime/option-button-content/verification.md",
        },
      } : {}),
      ...(refinement.contrastAcceptance ? { contrastAcceptance: optionButtonContentContrastAcceptance } : {}),
      doesNotAuthorize: [
        "other-sizes-new-tokens-or-new-dependencies", "existing-component-migration-or-question-number-contrast-exceptions",
        "business-progress-appeals-or-grading-workflows", "figma-publication-business-migration-or-git",
      ],
    });
}

export function hasOptionButtonRefinementAuthorization(status) {
  const refinement = status?.componentRefinements?.optionButton;
  if (!refinement) return false;
  const accepted = refinement.humanGate === "accepted";
  const content = refinement.contentRefinement;
  return status?.currentPhase?.id === "token-foundations-v1"
    && ["in-progress", "completed"].includes(refinement.implementation)
    && ["not-run", "failed", "passed"].includes(refinement.automatedVerification)
    && ["not-run", "findings", "passed"].includes(refinement.independentReview)
    && ["not-evaluated", "awaiting_human", "accepted"].includes(refinement.humanGate)
    && ((!accepted && refinement.implementation !== "completed")
      || (refinement.implementation === "completed" && refinement.automatedVerification === "passed" && refinement.independentReview === "passed"))
    && (!accepted || Boolean(exactRecord(refinement.humanGateDecision, {
      acceptedAt: "2026-09-08", decisionSource: "explicit-user-confirmation",
      userStatement: "视觉没问题。推进下一步", scope: "option-button-32-selection-visual-only",
      evidence: "../evidence/runtime/option-button/verification.md",
    })))
    && (content === undefined || (accepted && validOptionButtonContentRefinement(content)))
    && exactRecord(refinement, {
      authorization: "authorized", authorizedAt: "2026-09-08",
      decisionSource: "explicit-user-continue-next-question-option-batch", userStatement: "继续推进下一批",
      scope: "option-button-32-single-multiple-standalone-and-text-row",
      plan: "../docs/plans/2026-09-08-option-button-implementation.md", designConfirmation: "accepted",
      implementation: refinement.implementation, automatedVerification: refinement.automatedVerification,
      independentReview: refinement.independentReview, humanGate: refinement.humanGate,
      ...(accepted ? { humanGateDecision: refinement.humanGateDecision } : {}),
      ...(content !== undefined ? { contentRefinement: content } : {}),
      doesNotAuthorize: [
        "other-sizes-result-feedback-readonly-judgment-or-rich-media", "existing-component-migration-or-visual-changes",
        "new-dependencies-or-business-progress", "figma-publication-business-migration-or-git",
      ],
    });
}

export function hasOptionButtonContentRefinementAuthorization(status) {
  return hasOptionButtonRefinementAuthorization(status)
    && validOptionButtonContentRefinement(status.componentRefinements.optionButton.contentRefinement);
}

export function getValidatedTailwindB2History(status) {
  const fail = () => { throw new Error("Invalid Token Foundations V1 history: the complete frozen B2 state and existing Gates must remain unchanged"); };
  const history = status?.phaseHistory?.tailwindB2;
  if (status?.currentPhase?.id !== "token-foundations-v1" || !history
    || createHash("sha256").update(JSON.stringify(history)).digest("hex") !== "fb9b518f55944a74c8081d88a83d2385c8615e95887efe0cd1eae9b16ae186fe"
    || !exactRecord(status.phaseHistory, { foundationSpikeDay3: history.phaseHistory?.foundationSpikeDay3, tailwindB2: history })) fail();
  for (const key of ["schemaVersion", "kind", "preparationOutputs", "preparationChecks", "componentRefinements", "componentHumanGates", "independentAuditCheckpoints", "pendingGitActions"]) {
    const current = key === "componentRefinements"
      ? Object.fromEntries(Object.entries(status[key]).filter(([name]) =>
        !(name === "tag" && hasTagRefinementAuthorization(status))
        && !(name === "input" && hasInputRefinementAuthorization(status))
        && !(name === "iconButton" && hasIconButtonRefinementAuthorization(status))
        && !(name === "questionNumber" && hasQuestionNumberRefinementAuthorization(status))
        && !(name === "optionButton" && hasOptionButtonRefinementAuthorization(status))
        && !(name === "questionOptionSizes" && hasQuestionOptionSizeRefinementAuthorization(status)))
        .map(([name, record]) => [name, name === "textButton" && exactRecord(record, {
          ...history.componentRefinements.textButton, humanGate: "accepted", humanGateDecision: textButtonVisualAcceptance,
        }) ? history.componentRefinements.textButton : record]))
      : status[key];
    if (JSON.stringify(current) !== JSON.stringify(history[key])) fail();
  }
  validateTailwindB2Phase(history);
  return history;
}

export function getCurrentB2Status(status) {
  return status?.currentPhase?.id === "token-foundations-v1" ? getValidatedTailwindB2History(status) : status;
}

export const buttonTextContrastException = Object.freeze({
  id: "danger-primary-label",
  decisionSource: "explicit-user-acceptance-danger-primary-text-contrast",
  userStatement: "不满足文字对比度也没事。我认为能看清。normal使用fill-red-solid-2，hover时底色加深",
  variant: "primary", tone: "danger", part: "label", foreground: "OnColor/1",
  defaultFill: "Fill/Red/Solid/2",
  feedbackFills: { light: "Fill/Red/Solid/1", dark: "Fill/Red/Solid/2" },
  darkFeedbackAlpha: 85,
  loadingFills: { light: "Fill/Red/Solid/1", dark: "Fill/Red/Solid/2" },
  loadingSurfaceOpacity: 0.82,
  states: ["default", "hover", "pressed", "loading"],
  themes: ["light", "dark"],
  parentSurfaces: ["Background/Neutral/1", "Background/Neutral/3"],
  minimumContrast: 4.5,
  outcome: "report-actual-contrast-user-accepted",
});

export function validateTokenFoundationsV1Phase(status) {
  const fail = (reason) => { throw new Error(`Invalid Token Foundations V1 phase contract: ${reason}`); };
  const history = getValidatedTailwindB2History(status);
  const phase = status.currentPhase;
  const expectedKeys = [...Object.keys(history), ...(status.tokenRefinements ? ["tokenRefinements"] : []), ...(hasQuestionOptionSizeReviewAuthorization(status) ? ["localExperiments"] : [])];
  if (JSON.stringify(Object.keys(status).sort()) !== JSON.stringify(expectedKeys.sort())) fail("unknown status fields");
  if (status.tokenRefinements) {
    const buttonMigration = status.tokenRefinements.buttonTokenMigration;
    if (buttonMigration && (!["in-progress", "completed"].includes(buttonMigration.implementation)
      || !["not-run", "failed", "passed"].includes(buttonMigration.automatedVerification)
      || !["not-run", "findings", "passed"].includes(buttonMigration.independentReview)
      || !["awaiting_human", "accepted"].includes(buttonMigration.humanGate)
      || (buttonMigration.humanGate === "accepted" && buttonMigration.implementation !== "completed")
      || (buttonMigration.focusMigration?.humanGate === "accepted" && buttonMigration.implementation !== "completed")
      || (buttonMigration.implementation === "completed" && (buttonMigration.automatedVerification !== "passed" || buttonMigration.independentReview !== "passed"))
      || !exactRecord(buttonMigration, {
        authorization: "authorized", authorizedAt: "2026-09-06",
        decisionSource: "explicit-user-request-continue-button-token-migration",
        scope: "button-and-text-button-token-recipes",
        design: "../docs/plans/2026-09-05-size-density-first-recipes.md",
        implementation: buttonMigration.implementation, automatedVerification: buttonMigration.automatedVerification,
        independentReview: buttonMigration.independentReview, humanGate: buttonMigration.humanGate,
        ...(buttonMigration.humanGate === "accepted" ? {
          humanGateDecision: {
            acceptedAt: "2026-09-08", decisionSource: "explicit-user-confirmation",
            userStatement: "普通 Button：最新 Token 配方的整体验确认\nTextButton：最新配方的视觉验收确认",
            scope: "button-and-text-button-current-token-recipes-visual-only",
            evidence: "../docs/plans/2026-09-05-size-density-first-recipes.md",
          },
        } : {}),
        unresolved: [],
        focusMigration: {
          authorization: "authorized", authorizedAt: "2026-09-07",
          decisionSource: "explicit-user-request-global-two-layer-focus",
          scope: "all-keyboard-focusable-library-components",
          ...(buttonMigration.focusMigration?.humanGate ? {
            humanGate: "accepted",
            humanGateDecision: {
              acceptedAt: "2026-09-07", decisionSource: "explicit-user-confirmation",
              userStatement: "确定。", scope: "global-two-layer-focus-only",
            },
          } : {}),
          outline: "Border/Brand/1", halo: "Fill/Brand/Alpha/3",
          outlineWidth: "1px", outlineOffset: "0px", haloWidth: "3px",
          buttonOuterShadowWidths: { primary: "4px", secondaryAndTertiary: "3px", text: "3px" },
          forcedColors: { outline: "2px solid CanvasText", outlineOffset: "2px", boxShadow: "none" },
          doesNotAuthorize: ["non-focus-component-states", "new-public-color-values", "figma-publication-business-migration-or-git"],
        },
        contrastException: buttonTextContrastException,
        doesNotAuthorize: ["new-public-color-values", "global-size-density-remapping", "figma-publication-business-migration-or-git"],
      }))) fail("Button Token migration scope or lifecycle");
    const alignment = status.tokenRefinements.foundationsAlignment;
    if (alignment && (!["in-progress", "completed"].includes(alignment.implementation)
      || !["not-run", "failed", "passed"].includes(alignment.automatedVerification)
      || !["not-run", "findings", "passed"].includes(alignment.independentReview)
      || (alignment.implementation === "completed" && (alignment.automatedVerification !== "passed" || alignment.independentReview !== "passed"))
      || !exactRecord(alignment, {
        authorization: "authorized", authorizedAt: "2026-09-06",
        decisionSource: "explicit-user-confirmation-foundations-entry-and-token-alignment",
        scope: "equal-value-aliases-and-foundations-entry",
        design: "../docs/plans/2026-09-06-foundations-alignment.md",
        implementation: alignment.implementation, automatedVerification: alignment.automatedVerification,
        independentReview: alignment.independentReview, humanGate: "awaiting_human", colorMigration: "proposal-only",
        doesNotAuthorize: ["changed-visual-values-or-component-color-migration", "figma-publication-business-migration-or-git"],
      }))) fail("Foundations alignment scope or lifecycle");
    const colorAlignment = status.tokenRefinements.foundationsColorAlignment;
    if (colorAlignment && (!["in-progress", "completed"].includes(colorAlignment.implementation)
      || !["not-run", "failed", "passed"].includes(colorAlignment.automatedVerification)
      || !["not-run", "findings", "passed"].includes(colorAlignment.independentReview)
      || (colorAlignment.implementation === "completed" && (colorAlignment.automatedVerification !== "passed" || colorAlignment.independentReview !== "passed"))
      || !exactRecord(colorAlignment, {
        authorization: "authorized", authorizedAt: "2026-09-06",
        decisionSource: "explicit-user-correction-foundations-color-mapping",
        scope: "confirmed-semantic-color-aliases-and-role-splits",
        design: "../docs/plans/2026-09-06-foundations-color-alignment.md",
        implementation: colorAlignment.implementation, automatedVerification: colorAlignment.automatedVerification,
        independentReview: colorAlignment.independentReview, humanGate: "awaiting_human",
        accessibility: "open-placeholder-and-consumer-eligibility",
        doesNotAuthorize: ["unconfirmed-color-mappings-or-new-color-values", "full-component-dark-migration", "figma-publication-business-migration-or-git"],
      }))) fail("Foundations color alignment scope or lifecycle");
    const refinement = status.tokenRefinements.colorFamilySupplement;
    const dark = status.tokenRefinements.colorDarkTheme;
    const humanGateDecision = {
      acceptedAt: "2026-09-06",
      decisionSource: "explicit-user-confirmation",
      userStatement: "这些颜色token的视觉已没问题。接下来应该做什么？",
      scope: "color-token-visual-only",
      evidence: "../evidence/runtime/color-dark-theme/verification.md",
    };
    for (const record of [refinement, dark].filter(Boolean)) {
      if (!["awaiting_human", "accepted"].includes(record.humanGate)
        || (record.humanGate === "accepted" && record.implementation !== "completed")) fail("color visual acceptance");
    }
    if (!exactRecord(status.tokenRefinements, {colorFamilySupplement: refinement, ...(dark ? {colorDarkTheme: dark} : {}), ...(alignment ? {foundationsAlignment: alignment} : {}), ...(colorAlignment ? {foundationsColorAlignment: colorAlignment} : {}), ...(buttonMigration ? {buttonTokenMigration: buttonMigration} : {})}) || !refinement
      || !["in-progress", "completed"].includes(refinement.implementation)
      || !["not-run", "failed", "passed"].includes(refinement.automatedVerification)
      || !["not-run", "findings", "passed"].includes(refinement.independentReview)
      || (refinement.implementation === "completed" && (refinement.automatedVerification !== "passed" || refinement.independentReview !== "passed"))
      || !exactRecord(refinement, {
        authorization: "authorized", authorizedAt: "2026-09-06",
        decisionSource: "explicit-user-confirmation-and-continue-after-supplement-plan",
        scope: "48-light-color-records-pairing-validation-and-playground",
        design: "../docs/plans/2026-09-06-color-family-supplement-design.md",
        implementation: refinement.implementation, automatedVerification: refinement.automatedVerification,
        independentReview: refinement.independentReview, humanGate: refinement.humanGate,
        ...(refinement.humanGate === "accepted" ? {humanGateDecision} : {}),
        doesNotAuthorize: ["existing-component-color-migration", "new-color-values-or-dark-theme", "figma-publication-business-migration-or-git"],
      })) fail("color supplement scope or lifecycle");
    if (dark && (!["in-progress", "completed"].includes(dark.implementation)
      || !["not-run", "failed", "passed"].includes(dark.automatedVerification)
      || !["not-run", "findings", "passed"].includes(dark.independentReview)
      || (dark.implementation === "completed" && (dark.automatedVerification !== "passed" || dark.independentReview !== "passed"))
      || !exactRecord(dark, {
        authorization: "authorized", authorizedAt: "2026-09-06",
        decisionSource: "explicit-user-authorization-dark-token-library-and-playground",
        scope: "105-dark-color-values-theme-output-and-playground",
        design: "../docs/plans/2026-09-06-color-dark-theme.md",
        implementation: dark.implementation, automatedVerification: dark.automatedVerification,
        independentReview: dark.independentReview, humanGate: dark.humanGate,
        ...(dark.humanGate === "accepted" ? {humanGateDecision} : {}),
        doesNotAuthorize: ["existing-component-semantic-migration", "new-or-adjusted-color-values", "figma-publication-business-migration-or-git"],
      }))) fail("Dark color scope or lifecycle");
  }
  if (!exactRecord(status.metadata, {
    project: "rain-classroom-vibe-ui-spike", updatedAt: "2026-09-05",
    decisionSource: "explicit-user-authorization-token-foundations-v1-batch-0-1",
  }) || !exactRecord(phase, {
    id: "token-foundations-v1", label: "Token Foundations V1 第 0/1 批", status: "authorized",
    workMode: "system-mode-token-foundations",
    objective: "增量建设已确认的颜色登记、字体、线条、圆角与间距基础，保留既有运行视觉和独立验收。",
    authorizationScope: "token-foundations-v1-batch-0-1", progress: phase.progress,
  })) fail("authorization");
  if (JSON.stringify(status.allowedActions) !== JSON.stringify(tokenFoundationsV1AllowedActions)
    || JSON.stringify(status.blockedActions) !== JSON.stringify(tokenFoundationsV1BlockedActions)) fail("action allowlist");
  if (JSON.stringify(status.checkpoints) !== JSON.stringify([...history.checkpoints, tokenFoundationsV1Checkpoint])) fail("checkpoint");
  if (!exactRecord(status.independentLifecycle, getExpectedTokenFoundationsV1Lifecycle(phase.progress, status.independentLifecycle?.automatedVerification))) fail("lifecycle");
}

export function getValidatedDayThreeHistory(status) {
  const expectedPhase = {
    id: "foundation-spike-day-3", label: "Foundation Spike Day 3", status: "authorized",
    workMode: "system-mode-ui",
    objective: "实现 Button、Input、Tag/Badge 与 Surface/Card 四个基础 UI 家族，并补齐可运行说明与真实浏览器证据。",
    authorizationScope: "day-3-task-4-core-ui-families", progress: "task-4-core-ui-completed",
  };
  const history = status?.phaseHistory?.foundationSpikeDay3;
  if (status?.currentPhase?.id !== "tailwind-b2-composition-contract"
    || !exactRecord(status.phaseHistory, { foundationSpikeDay3: history })
    || !exactRecord(history, { currentPhase: history?.currentPhase, independentLifecycle: history?.independentLifecycle })
    || !exactRecord(history.currentPhase, expectedPhase)
    || !exactRecord(history.independentLifecycle, getExpectedDayThreeLifecycle("task-4-core-ui-completed", "passed"))) {
    throw new Error("Invalid B2 Day 3 history: an exact completed and verified parent snapshot is required");
  }
  return history;
}

export function validateTailwindB2Phase(status) {
  const fail = (reason) => { throw new Error(`Invalid B2 phase contract: ${reason}`); };
  getValidatedDayThreeHistory(status);
  const phase = status.currentPhase;
  if (phase.status !== "authorized" || phase.workMode !== "system-mode-tailwind-b2"
    || phase.authorizationScope !== "input-button-search-operation-pilot"
    || typeof phase.label !== "string" || phase.label.trim().length === 0
    || typeof phase.objective !== "string" || phase.objective.trim().length === 0
    || Object.keys(phase).sort().join(",") !== "authorizationScope,id,label,objective,progress,status,workMode"
    || status.metadata?.decisionSource !== "explicit-user-authorization-tailwind-b2-composition-contract") fail("authorization");
  if (JSON.stringify(status.allowedActions) !== JSON.stringify(tailwindB2AllowedActions)
    || JSON.stringify(status.blockedActions) !== JSON.stringify(tailwindB2BlockedActions)) fail("action allowlist");
  const refinements = status.componentRefinements;
  for (const [record, humanGate] of [
    [refinements?.iconLibrary, "accepted"],
    [refinements?.iconLibrary?.sourceRepair, "accepted"],
    [refinements?.textButton, "awaiting_human"],
  ]) {
    if (record?.implementation !== "completed" || record?.automatedVerification !== "passed"
      || record?.humanGate !== humanGate) fail("preserved component refinements");
  }
  if (!exactRecord(status.independentLifecycle,
    getExpectedTailwindB2Lifecycle(phase.progress, status.independentLifecycle?.automatedVerification))) fail("lifecycle");
  if (JSON.stringify(status.checkpoints?.map(({ id }) => id)) !== JSON.stringify([
    "day-1-runtime-start", "day-2-foundations-start", "day-3-core-ui-start", "tailwind-b2-composition-contract",
  ]) || !tailwindB2PriorCheckpoints.every((checkpoint, index) => exactRecord(status.checkpoints?.[index], checkpoint))
    || !exactRecord(status.checkpoints?.[3], tailwindB2Checkpoint)) fail("checkpoint");
}

export function getTextButtonRefinementFiles(refinements, parentProgress) {
  const empty = {
    application: [], ui: [], workspace: [], evidence: [], required: [], requireComplete: false,
  };
  if (refinements === undefined) return empty;
  const fail = () => {
    throw new Error("Invalid TextButton refinement authorization or lifecycle");
  };
  if (
    parentProgress !== "task-4-core-ui-completed" ||
    !refinements ||
    !Object.hasOwn(refinements, "textButton") ||
    Object.keys(refinements).some((key) => !["textButton", "iconLibrary"].includes(key))
  ) fail();
  const iconsReplacePrivateFixture = Object.hasOwn(refinements, "iconLibrary")
    && getIconLibraryRefinementFiles(refinements, parentProgress).requireComplete;

  const record = refinements.textButton;
  if (!record || typeof record !== "object" || Array.isArray(record)) fail();
  const complete = record.implementation === "completed";
  const inProgress = record.implementation === "in-progress";
  if (
    (!complete && !inProgress) ||
    (complete && (record.automatedVerification !== "passed" || !["awaiting_human", "accepted"].includes(record.humanGate))) ||
    (inProgress && (!['not-run', 'failed', 'passed'].includes(record.automatedVerification) || record.humanGate !== "not-evaluated"))
  ) fail();

  const expected = {
    authorization: "authorized",
    authorizedAt: "2026-09-03",
    decisionSource: "explicit-user-request-for-text-button-implementation",
    scope: "button-text-variant-link-recipe-and-interactive-review-page",
    design: "../docs/plans/2026-09-03-text-button-design.md",
    plan: "../docs/plans/2026-09-03-text-button-implementation.md",
    designConfirmation: "accepted",
    implementation: record.implementation,
    automatedVerification: record.automatedVerification,
    humanGate: record.humanGate,
    ...(record.humanGate === "accepted" ? { humanGateDecision: textButtonVisualAcceptance } : {}),
    doesNotAuthorize: [
      "other-component-redesigns",
      "current-phase-advance",
      "new-dependencies-or-headless-selection",
      "figma-write-or-publication",
      "package-or-registry-publication",
      "business-migration",
      "local-or-remote-git",
    ],
  };
  if (
    Object.keys(record).length !== Object.keys(expected).length ||
    Object.entries(expected).some(([key, value]) => JSON.stringify(record[key]) !== JSON.stringify(value))
  ) fail();

  const files = {
    application: [
      "apps/playground/src/docs/components/text-button-page.tsx",
      "apps/playground/src/docs/components/text-button-page.css",
      "apps/playground/src/docs/components/text-button-page.test.tsx",
      ...(!iconsReplacePrivateFixture ? ["apps/playground/src/docs/components/text-button-icons.tsx"] : []),
    ],
    ui: [
      "packages/ui/src/button/button-text.test.tsx",
      "packages/ui/src/link/link.tsx",
      "packages/ui/src/link/link.test.tsx",
    ],
    workspace: ["tests/e2e/text-button.spec.ts"],
    evidence: [
      "evidence/runtime/day-3/text-button-desktop.png",
      "evidence/runtime/day-3/text-button-mobile.png",
    ],
    requireComplete: complete,
  };
  return {
    ...files,
    required: complete ? [
      ...files.application, ...files.ui, ...files.workspace, ...files.evidence,
      "docs/verification/2026-09-03-text-button-implementation.md",
    ] : [],
  };
}

export function getIconLibraryRefinementFiles(refinements, parentProgress, inventory, questionNumberAuthorized = false) {
  const empty = {
    authorized: false, application: [], ui: [], foundations: [], workspace: [],
    evidence: [], documents: [], sourceExports: [], referencedEvidence: [], generated: [],
    required: [], requireComplete: false, uiExports: {}, foundationsExports: {},
  };
  if (refinements === undefined) return empty;
  const fail = () => { throw new Error("Invalid Icon library refinement authorization or lifecycle"); };
  if (!refinements || typeof refinements !== "object" || Array.isArray(refinements)
    || Object.keys(refinements).some((key) => !["textButton", "iconLibrary"].includes(key))) fail();
  if (!Object.hasOwn(refinements, "iconLibrary")) return empty;
  if (parentProgress !== "task-4-core-ui-completed") fail();
  const record = refinements.iconLibrary;
  if (!record || typeof record !== "object" || Array.isArray(record)) fail();
  const complete = record.implementation === "completed";
  if ((!complete && record.implementation !== "in-progress")
    || (complete && (record.automatedVerification !== "passed" || !["awaiting_human", "accepted"].includes(record.humanGate)))
    || (!complete && (!['not-run', 'failed', 'passed'].includes(record.automatedVerification)
      || record.humanGate !== "not-evaluated"))) fail();
  const hasSourceRepair = Object.hasOwn(record, "sourceRepair");
  let expectedSourceRepair;
  let sourceRepairComplete = false;
  if (hasSourceRepair) {
    const repair = record.sourceRepair;
    if (record.humanGate !== "accepted" || !repair || typeof repair !== "object" || Array.isArray(repair)) fail();
    sourceRepairComplete = repair.implementation === "completed";
    if ((!sourceRepairComplete && repair.implementation !== "in-progress")
      || (sourceRepairComplete && (repair.automatedVerification !== "passed"
        || !["awaiting_human", "accepted"].includes(repair.humanGate)))
      || (!sourceRepairComplete && (!["not-run", "failed", "passed"].includes(repair.automatedVerification)
        || repair.humanGate !== "awaiting_human"))) fail();
    expectedSourceRepair = {
      authorization: "authorized",
      authorizedAt: "2026-09-03",
      decisionSource: "explicit-user-request-to-repair-two-source-icon-anomalies",
      userStatement: "修复两个源图形异常",
      scope: "two-source-icons-original-geometry-repair-and-local-reexport",
      source: {
        fileKey: "olqwu95QD6n4Y3IAwUdgF4",
        nodes: [
          { assetId: "icon/editor-redo", nodeId: "84:35" },
          { assetId: "icon/editor-undo", nodeId: "84:32" },
        ],
      },
      allowedActions: [
        "restore-original-geometry-only-at-listed-source-nodes",
        "reexport-two-icons-and-update-local-runtime-and-evidence",
      ],
      evidence: "../evidence/icons/source-repairs.json",
      visualEvidence: "../evidence/runtime/icon-migration/source-repair.png",
      implementation: repair.implementation,
      automatedVerification: repair.automatedVerification,
      humanGate: repair.humanGate,
      ...(repair.humanGate === "accepted" ? {
        humanGateDecision: {
          acceptedAt: "2026-09-03",
          decisionSource: "explicit-user-confirmation",
          userStatement: "确定",
          scope: "two-source-icons-visual-only",
          evidence: "../evidence/runtime/icon-migration/verification.md",
        },
      } : {}),
      doesNotAuthorize: [
        "other-figma-node-writes", "figma-component-or-variant-publication",
        "other-component-redesigns", "current-phase-advance",
        "new-dependencies-or-headless-selection", "package-or-registry-publication",
        "business-migration", "local-or-remote-git",
      ],
    };
    if (Object.keys(repair).length !== Object.keys(expectedSourceRepair).length
      || Object.entries(expectedSourceRepair).some(([key, value]) => JSON.stringify(repair[key]) !== JSON.stringify(value))) fail();
  }
  const expected = {
    authorization: "authorized",
    authorizedAt: "2026-09-03",
    decisionSource: "explicit-user-request-to-enter-icon-library-implementation",
    scope: "full-figma-icon-library-runtime-and-ai-consumption",
    plan: "../docs/plans/2026-09-03-icon-library-migration.md",
    preflight: "../docs/audits/2026-09-03-icon-migration-preflight.md",
    baseline: "../evidence/runtime/icon-migration/baseline.json",
    source: { fileKey: "olqwu95QD6n4Y3IAwUdgF4", pageId: "1:3" },
    implementation: record.implementation,
    automatedVerification: record.automatedVerification,
    humanGate: record.humanGate,
    ...(record.humanGate === "accepted" ? {
      humanGateDecision: {
        acceptedAt: "2026-09-03",
        decisionSource: "explicit-user-confirmation",
        userStatement: "视觉验收完成",
        scope: "icon-library-visual-only",
        evidence: "../evidence/runtime/icon-migration/verification.md",
      },
    } : {}),
    ...(hasSourceRepair ? { sourceRepair: record.sourceRepair } : {}),
    doesNotAuthorize: [
      "other-component-redesigns", "current-phase-advance",
      "new-dependencies-or-headless-selection", "figma-write-or-publication",
      "package-or-registry-publication", "business-migration", "local-or-remote-git",
    ],
  };
  if (Object.keys(record).length !== Object.keys(expected).length
    || Object.entries(expected).some(([key, value]) => JSON.stringify(record[key]) !== JSON.stringify(value))) fail();
  const entries = inventory === undefined ? [] : validateIconLibraryInventory(inventory, questionNumberAuthorized);
  const generated = entries.filter((icon) => icon.availability === "available");
  const sourceExports = entries.flatMap((icon) => [icon.sourceExport?.path, icon.rasterExport?.path].filter(Boolean));
  const sourceRepairEvidence = hasSourceRepair ? [
    "evidence/icons/source-repairs.json",
    "evidence/runtime/icon-migration/source-repair.png",
  ] : [];
  const sourceRepairWorkspace = hasSourceRepair ? ["tests/e2e/icon-source-repair.spec.ts"] : [];
  const pendingSourceRepairFiles = sourceRepairComplete ? [] : [...sourceRepairEvidence, ...sourceRepairWorkspace];
  const files = {
    authorized: true,
    application: [
      "apps/playground/src/docs/icons-page.tsx",
      "apps/playground/src/docs/icons-page.css",
      "apps/playground/src/docs/icons-page.test.tsx",
    ],
    ui: [
      "packages/ui/src/icon/icon.tsx", "packages/ui/src/icon/icon.test.tsx",
      "packages/ui/src/icons/catalog.generated.ts",
      ...generated.flatMap((icon) => [icon.runtime.modulePath, icon.runtime.assetPath]),
    ],
    foundations: [
      "packages/foundations/src/icons/icon-contract.ts",
      "packages/foundations/src/icons/semantic-rules.json",
      "packages/foundations/src/icons/semantic-rules.generated.ts",
      "packages/foundations/src/icons/catalog.generated.ts",
      "packages/foundations/src/icons/semantic-rules.test.ts",
    ],
    workspace: [
      "scripts/generate-icons.mjs", "scripts/generate-icons.test.ts",
      "scripts/generate-icon-semantics.mjs", "scripts/generate-icon-semantics.test.ts",
      "scripts/verify-icons.mjs", "scripts/verify-icons.test.ts", "tests/e2e/icons.spec.ts",
      "tests/e2e/icon-rendering.spec.ts",
      ...sourceRepairWorkspace,
    ],
    evidence: [
      "evidence/icons/source-lock.yaml", "evidence/icons/inventory.json", "evidence/icons/README.md",
      "evidence/icons/source-nodes.json", "evidence/icons/color-decisions.json", "evidence/icons/source-failures.json",
      ...(questionNumberAuthorized ? ["evidence/icons/source-additions.json"] : []),
      "evidence/runtime/icon-migration/baseline.json",
      "evidence/runtime/icon-migration/verification.md",
      "evidence/runtime/icon-migration/vibe-coding-cases.md",
      "evidence/runtime/icon-migration/visual-references.json",
      "evidence/runtime/icon-migration/consumer-bundle.json",
      "evidence/runtime/icon-migration/gallery.png",
      "evidence/runtime/icon-migration/semantic-examples.png",
      "evidence/runtime/icon-migration/source-failures.png",
      "evidence/runtime/icon-migration/color-review.png",
      "evidence/runtime/icon-migration/vibe-consumer.tsx",
      "evidence/runtime/icon-migration/vibe-consumer.png",
      "evidence/runtime/icon-migration/baseline-comparison.json",
      ...sourceRepairEvidence,
    ],
    documents: [
      "docs/ai/icon-selection.md", "manifests/icons.json", "registry/icons.json",
      "docs/adr/0001-icon-assets-and-semantic-consumption.md",
    ],
    sourceExports,
    referencedEvidence: [...new Set([
      ...sourceExports, ...entries.flatMap((icon) => icon.sourceFailure ? [icon.sourceFailure.evidencePath] : []),
    ])],
    generated, requireComplete: complete,
    uiExports: {
      "./icon": "./src/icon/icon.tsx",
      "./icons/catalog": "./src/icons/catalog.generated.ts",
      ...Object.fromEntries(generated.map((icon) => [`./icons/${icon.slug}`, `./src/icons/${icon.slug}.tsx`])),
    },
    foundationsExports: {
      "./icons/icon-contract": "./src/icons/icon-contract.ts",
      "./icons/semantic-rules": "./src/icons/semantic-rules.generated.ts",
      "./icons/catalog": "./src/icons/catalog.generated.ts",
    },
  };
  return { ...files, required: complete ? [
    ...files.application, ...files.ui, ...files.foundations, ...files.workspace,
    ...files.evidence, ...files.documents, ...files.sourceExports,
  ].filter((file) => !pendingSourceRepairFiles.includes(file)) : [] };
}

function validateIconLibraryInventory(inventory, questionNumberAuthorized = false) {
  const additions = questionNumberAuthorized && inventory?.sourceAdditions;
  const addedSources = { "grading-pending": ["2761:19670", "2761:19672"], "grading-reviewed": ["2761:19678", "2761:19680"] };
  const fail = (reason) => { throw new Error(`Icon inventory ${reason}`); };
  if (!inventory || inventory.schemaVersion !== "1.0"
    || inventory.source?.fileKey !== "olqwu95QD6n4Y3IAwUdgF4"
    || inventory.source?.pageId !== "1:3"
    || !Array.isArray(inventory.icons) || inventory.icons.length === 0
    || (additions && inventory.source.count !== 897)
    || inventory.source.count + (additions ? 2 : 0) !== inventory.icons.length) fail("source or count is invalid");
  if (additions && (!exactRecord(additions, { path: "evidence/icons/source-additions.json", sha256: additions.sha256, count: 2 })
    || !/^[a-f0-9]{64}$/.test(additions.sha256)
    || inventory.icons.filter((icon) => Object.hasOwn(addedSources, icon.slug)).length !== 2)) fail("source additions are invalid");
  const availableCount = inventory.icons.filter((icon) => icon?.availability === "available").length;
  if (inventory.availableCount !== availableCount
    || inventory.unavailableCount !== inventory.icons.length - availableCount) fail("availability counts are invalid");
  const identities = new Set();
  const slugs = new Set();
  const nodes = new Set();
  const components = new Set();
  const exports = new Set();
  for (const icon of inventory.icons) {
    const added = additions && Object.hasOwn(addedSources, icon?.slug ?? "");
    const nodesForAddition = addedSources[icon?.slug];
    if (added && (!exactRecord(icon.source, { fileKey: "MbWg1ft5zk1JRQiQ6dS30e", nodeId: nodesForAddition[0], foregroundNodeId: nodesForAddition[1], kind: "non-component" })
      || icon.nodeId !== nodesForAddition[0] || icon.componentKey !== null || icon.availability !== "available")) fail("supplemental source identity is invalid");
    if (!icon || icon.assetId !== `icon/${icon.slug}` || icon.name !== icon.assetId
      || !/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(icon.slug)
      || !/^\d+:\d+$/.test(icon.nodeId)
      || (!added && !/^[a-f0-9]{40}$/.test(icon.componentKey))
      || JSON.stringify(icon.canvas) !== (added ? "[12,12]" : "[24,24]")) fail("identity or canvas is invalid");
    if (identities.has(icon.assetId) || slugs.has(icon.slug) || nodes.has(icon.nodeId)
      || (icon.componentKey !== null && components.has(icon.componentKey))) fail("contains duplicate identities");
    identities.add(icon.assetId); slugs.add(icon.slug); nodes.add(icon.nodeId);
    if (icon.componentKey !== null) components.add(icon.componentKey);
    if (!["available", "source-unavailable"].includes(icon.availability)) fail("availability is invalid");
    if (icon.rasterExport != null && (
      icon.rasterExport.path !== `evidence/icons/source-exports/${icon.slug}.png`
      || !/^[a-f0-9]{64}$/.test(icon.rasterExport.sha256)
    )) fail("raster evidence path or hash is invalid");
    if (icon.availability === "source-unavailable") {
      if (icon.runtime != null || icon.sourceExport != null || icon.rendering != null || icon.viewBox != null) {
        fail("unavailable source must not expose runtime or SVG output");
      }
      if (icon.sourceFailure?.evidencePath !== "evidence/icons/source-failures.json"
        || typeof icon.sourceFailure.error !== "string" || icon.sourceFailure.error.trim().length === 0) {
        fail("unavailable source requires explicit failure evidence");
      }
      continue;
    }
    if (icon.sourceFailure != null || icon.viewBox !== (added ? "0 0 12 12" : "0 0 24 24")) fail("available source evidence or viewBox is invalid");
    if (exports.has(icon.runtime?.exportName)) fail("contains duplicate runtime exports");
    exports.add(icon.runtime?.exportName);
    const sourcePath = icon.sourceExport?.path;
    const assetPath = icon.runtime?.assetPath;
    const pascalName = icon.slug.split("-").map((word) => word.charAt(0).toUpperCase() + word.slice(1)).join("");
    const exportName = /^\d/.test(pascalName) ? `Icon${pascalName}` : `${pascalName}Icon`;
    if (sourcePath !== (added ? `evidence/icons/source-additions/${icon.slug}.source.svg` : `evidence/icons/source-exports/${icon.slug}.svg`)
      || !/^[a-f0-9]{64}$/.test(icon.sourceExport?.sha256)
      || icon.runtime?.modulePath !== `packages/ui/src/icons/${icon.slug}.tsx`
      || !["svg", "png"].some((extension) => assetPath === `packages/ui/src/icons/assets/${icon.slug}.${extension}`)
      || icon.runtime?.exportName !== exportName) fail("file path or export is invalid");
    const isRasterRuntime = assetPath.endsWith(".png");
    if ((isRasterRuntime && icon.rasterExport == null)
      || icon.runtime.sourcePath !== (isRasterRuntime ? icon.rasterExport.path : sourcePath)) {
      fail("runtime must reference its registered source export");
    }
    if (!(["svg-mask", "png-mask"].includes(icon.rendering) && icon.colorMode === "host")
      && !(icon.rendering === "image" && icon.colorMode === "intrinsic")) fail("color or rendering mode is invalid");
    if ((icon.rendering === "svg-mask" && !assetPath.endsWith(".svg"))
      || (icon.rendering === "png-mask" && !assetPath.endsWith(".png"))) fail("rendering asset extension is invalid");
  }
  return inventory.icons;
}

export function hasRainUiModuleDependency(source) {
  // Keep quoted examples opaque: metadata describing a UI import is not an import.
  const tokens = source.match(/\/\*[\s\S]*?\*\/|\/\/[^\n]*|"(?:\\[\s\S]|[^"\\])*"|'(?:\\[\s\S]|[^'\\])*'|`(?:\\[\s\S]|[^`\\])*`|[A-Za-z_$][\w$]*|[^\s]/g) ?? [];
  const code = tokens.filter((token) => !token.startsWith("//") && !token.startsWith("/*"));
  const isUiSpecifier = (token) => {
    if (!token || !["\"", "'", "`"].includes(token[0])) return false;
    const specifier = token.slice(1, -1)
      .replace(/\\u([0-9a-f]{4})|\\x([0-9a-f]{2})/gi, (_, unicode, hex) => String.fromCharCode(parseInt(unicode ?? hex, 16)))
      .replace(/\\([\\/'"])/g, "$1");
    return specifier === "@rain-next/ui" || specifier.startsWith("@rain-next/ui/");
  };
  return code.some((token, index) =>
    ((token === "from" || token === "import") && isUiSpecifier(code[index + 1]))
    || ((token === "import" || token === "require") && code[index + 1] === "(" && isUiSpecifier(code[index + 2])),
  );
}

export function usesPrivateReferenceColor(source) {
  if (typeof source !== "string") {
    throw new Error("source must be text");
  }
  const withoutComments = source
    .replace(/\/\*[\s\S]*?\*\//g, "")
    .replace(/\/\/[^\r\n]*/g, "");
  return /var\(\s*--rain-ref-[a-z0-9-]+\s*\)/i.test(withoutComments);
}

export function inspectPngMetadata(source) {
  if (!Buffer.isBuffer(source) || source.length < 33) {
    throw new Error("PNG evidence must contain a complete signature and IHDR chunk");
  }

  const expectedSignature = Buffer.from([
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a,
  ]);
  if (!source.subarray(0, 8).equals(expectedSignature)) {
    throw new Error("PNG evidence has an invalid file signature");
  }
  if (
    source.readUInt32BE(8) !== 13 ||
    source.toString("ascii", 12, 16) !== "IHDR"
  ) {
    throw new Error("PNG evidence is missing the canonical IHDR chunk");
  }

  const width = source.readUInt32BE(16);
  const height = source.readUInt32BE(20);
  if (width < 1 || height < 1) {
    throw new Error("PNG evidence must declare positive IHDR dimensions");
  }

  return { height, width };
}

export function parsePnpmLockfileImporters(source) {
  if (typeof source !== "string") {
    throw new Error("pnpm lockfile source must be text");
  }

  const lines = source.replaceAll("\r\n", "\n").split("\n");
  const importerSectionIndexes = lines.flatMap((line, index) =>
    line === "importers:" ? [index] : [],
  );
  if (importerSectionIndexes.length !== 1) {
    throw new Error("pnpm lockfile must contain exactly one top-level importers section");
  }

  const importers = [];
  for (let index = importerSectionIndexes[0] + 1; index < lines.length; index += 1) {
    const line = lines[index];
    if (line.trim().length === 0) continue;
    if (!line.startsWith(" ")) break;
    if (!line.startsWith("  ") || line.startsWith("   ")) continue;

    const match = line.match(/^  (.+):\s*$/);
    if (!match) {
      throw new Error(`invalid top-level pnpm importer declaration: ${line}`);
    }

    let importer = match[1];
    if (
      (importer.startsWith('"') && importer.endsWith('"')) ||
      (importer.startsWith("'") && importer.endsWith("'"))
    ) {
      importer = importer.slice(1, -1);
    }
    importers.push(importer);
  }

  if (importers.length === 0) {
    throw new Error("pnpm lockfile importers section must not be empty");
  }
  return importers;
}
