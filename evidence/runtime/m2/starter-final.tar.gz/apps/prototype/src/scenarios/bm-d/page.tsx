import { useEffect, useRef, useState } from "react";
import { DensityProvider } from "@rain-next/foundations";
import { Grid, Inline, Stack } from "@rain-next/layouts";
import { Button, Checkbox, Empty, EmptyActions, EmptyDescription, EmptyTitle, FormItem, Pagination, Select, Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow, TableScrollArea } from "@rain-next/ui";
import { simulateTask } from "../bm-b/state";
import { reportData, summarize } from "./state";
import "./page.css";

function Statistic({ label, value, unit, detail }: { label: string; value: string; unit: string; detail: string }) {
  return <div className="bm-d-statistic" data-rain-id="local-statistic" data-slot="statistic"><dt data-slot="label">{label}</dt><dd><span className="rain-type-data" data-slot="value">{value}</span><span data-slot="unit">{unit}</span></dd><p>{detail}</p></div>;
}
const format = (value: number | null) => value === null ? "—" : value.toFixed(1);

export function LearningReportScenario({ loadTask = simulateTask }: { loadTask?: (signal: AbortSignal, fail: boolean) => Promise<void> }) {
  const [group, setGroup] = useState("全部班级"), [period, setPeriod] = useState("all"), [page, setPage] = useState(1);
  const [metric, setMetric] = useState<"average" | "completion">("average"), [selectedWeek, setSelectedWeek] = useState(6);
  const [dark, setDark] = useState(false), [empty, setEmpty] = useState(false), [failLoad, setFailLoad] = useState(false);
  const [loadState, setLoadState] = useState<"ready" | "loading" | "failed">("ready");
  const requestRef = useRef<AbortController | null>(null), statusRef = useRef<HTMLParagraphElement>(null);
  const firstWeek = period === "recent" ? 4 : 1;
  const rows = empty ? [] : reportData.filter(row => (group === "全部班级" || row.group === group) && row.week >= firstWeek);
  const totals = summarize(rows), weeks = [...new Set(rows.map(row => row.week))], groups = [...new Set(rows.map(row => row.group))];
  const week = weeks.includes(selectedWeek) ? selectedWeek : weeks[weeks.length - 1] ?? 0;
  const unit = metric === "average" ? "分" : "%", metricLabel = metric === "average" ? "平均分" : "提交率";
  const pointValue = (label: string, value: number) => summarize(rows.filter(row => row.group === label && row.week === value))[metric];
  const first = summarize(rows.filter(row => row.week === firstWeek)), last = summarize(rows.filter(row => row.week === 6));
  const x = (value: number) => 48 + (value - firstWeek) / Math.max(1, weeks.length - 1) * 624;
  const y = (value: number) => 220 - value * 1.8;
  useEffect(() => () => requestRef.current?.abort(), []);
  useEffect(() => { if (loadState === "failed") statusRef.current?.focus(); }, [loadState]);
  async function reload() {
    if (requestRef.current) return;
    const request = new AbortController(); requestRef.current = request; setLoadState("loading"); setFailLoad(false);
    try {
      await loadTask(request.signal, failLoad);
      if (!request.signal.aborted && requestRef.current === request) setLoadState("ready");
    } catch {
      if (!request.signal.aborted && requestRef.current === request) setLoadState("failed");
    } finally { if (requestRef.current === request && !request.signal.aborted) requestRef.current = null; }
  }
  function changeGroup(value: string) { if (!requestRef.current) { setGroup(value); setPage(1); } }

  return <main className="bm-d" data-rain-id="scenario-bm-d" data-asset-identity="local-experiment" data-rain-theme={dark ? "dark" : "light"}>
    <div className="bm-d-content"><Stack gap={24}>
      <header className="bm-d-header"><div><a href="#bm-c" data-focus="item">进入作业批改</a><p className="bm-d-eyebrow">大学物理 · 教学报告</p><h1>大学物理 · 学习报告</h1><p>从作业参与和学习表现，了解课堂的变化。</p></div>
        <Inline gap={8}><Button variant="secondary" disabled={loadState === "loading"} onClick={() => void reload()}>刷新报告</Button><Button variant="tertiary" onClick={() => setDark(!dark)}>{dark ? "切换浅色" : "切换深色"}</Button></Inline>
      </header>
      <div className="bm-d-filter"><Inline gap={8} aria-label="报告班级">{["全部班级", "一班", "二班"].map(value => <Button key={value} variant={group === value ? "secondary" : "tertiary"} aria-pressed={group === value} disabled={loadState === "loading"} onClick={() => changeGroup(value)}>{value}</Button>)}</Inline>
        <div className="bm-d-period"><FormItem label="报告周期" disabled={loadState === "loading"}><Select value={period} onValueChange={value => { if (value === "all" || value === "recent") { setPeriod(value); setPage(1); } }} options={[{ value: "all", label: "第 1–6 周" }, { value: "recent", label: "第 4–6 周" }]} /></FormItem></div>
      </div>
      <p className="bm-d-scope">统计范围：{group} · 第 {firstWeek}–6 周 · {rows.length} 条周度汇总；指标覆盖全部筛选数据。</p>
      {loadState !== "ready" ? <section className="bm-d-message"><p ref={statusRef} tabIndex={-1} role={loadState === "failed" ? "alert" : "status"}>{loadState === "failed" ? "报告加载失败，当前范围的数据尚未更新。" : "正在更新报告…"}</p>{loadState === "failed" && <Button onClick={() => void reload()}>重试加载</Button>}</section>
        : !rows.length ? <Empty><EmptyTitle>暂无报告数据</EmptyTitle><EmptyDescription>当前范围还没有可用的作业汇总。</EmptyDescription><EmptyActions><Button onClick={() => { setEmpty(false); setPage(1); }}>恢复示例数据</Button></EmptyActions></Empty>
        : <>
          <section aria-label="关键指标"><dl className="bm-d-metrics"><Grid columns={4} minColumnWidth={210} gap={0}>
            <Statistic label="应交作业" value={String(totals.expected)} unit="份" detail="每周应交份数之和" />
            <Statistic label="实际提交" value={String(totals.submissions)} unit="份" detail="每次提交按一份计" />
            <Statistic label="平均分" value={format(totals.average)} unit="分" detail="按提交份数加权 · 满分 100" />
            <Statistic label="提交率" value={`${format(totals.completion)}%`} unit="" detail="实际提交 ÷ 应交作业" />
          </Grid></dl></section>
          <section className="bm-d-summary"><h2>本期摘要</h2><p className="rain-type-reading">{group}在第 {firstWeek}–6 周共提交 {totals.submissions} 份作业，平均分为 {format(totals.average)} 分。第 {firstWeek} 周与第 6 周平均分分别为 {format(first.average)} 分、{format(last.average)} 分。</p><p className="rain-type-reading">这些数值描述当前教学样例，不用于推断教学因果。周度汇总没有学生身份，不能据此计算去重人数。</p></section>
          <div className="bm-d-report-layout">
          <section className="bm-d-trend" aria-labelledby="bm-d-trend-title"><Stack gap={20}>
            <Inline justify="between" gap={16}><div><h2 id="bm-d-trend-title">每周学习趋势</h2><p>查看各班的{metricLabel}，或选择一周读取具体数值。</p></div><Inline gap={4} aria-label="趋势指标"><Button variant={metric === "average" ? "secondary" : "tertiary"} aria-pressed={metric === "average"} onClick={() => setMetric("average")}>平均分</Button><Button variant={metric === "completion" ? "secondary" : "tertiary"} aria-pressed={metric === "completion"} onClick={() => setMetric("completion")}>提交率</Button></Inline></Inline>
            <figure><div className="bm-d-chart-scroll" role="region" aria-label="趋势图横向滚动区" tabIndex={0} data-focus="item"><svg className="bm-d-chart" viewBox="0 0 720 256" role="img" aria-labelledby="bm-d-chart-title bm-d-chart-desc">
              <title id="bm-d-chart-title">第 {firstWeek}–6 周各班{metricLabel}</title><desc id="bm-d-chart-desc">一班使用实线圆点，二班使用虚线方点。下方提供按周读数及完整数据表。</desc>
              {[0, 25, 50, 75, 100].map(value => <g key={value}><line className="bm-d-gridline" x1={48} x2={672} y1={y(value)} y2={y(value)} /><text x={36} y={y(value) + 4} textAnchor="end">{value}</text></g>)}
              <line className="bm-d-marker" x1={x(week)} x2={x(week)} y1={32} y2={220} />
              {groups.map(label => <g key={label} data-series={label === "一班" ? "one" : "two"}>
                <polyline className="bm-d-series" points={weeks.filter(value => pointValue(label, value) !== null).map(value => `${x(value)},${y(pointValue(label, value)!)}`).join(" ")} />
                {weeks.map(value => { const score = pointValue(label, value); return score === null ? null : label === "一班" ? <circle key={value} className="bm-d-point" cx={x(value)} cy={y(score)} r={4} /> : <rect key={value} className="bm-d-point" x={x(value) - 4} y={y(score) - 4} width={8} height={8} />; })}
              </g>)}
              {weeks.map(value => <text key={value} x={x(value)} y={246} textAnchor="middle">第 {value} 周</text>)}
            </svg></div><figcaption><span className="bm-d-legend-one">● 一班 · 实线</span><span className="bm-d-legend-two">■ 二班 · 虚线</span><span>纵轴 0–100{unit === "%" ? "%" : " 分"}</span></figcaption></figure>
            <Inline gap={8} aria-label="选择趋势周">{weeks.map(value => <Button key={value} variant={week === value ? "secondary" : "tertiary"} aria-pressed={week === value} onClick={() => setSelectedWeek(value)}>第 {value} 周</Button>)}</Inline>
            <p className="bm-d-readout" role="status" aria-label="趋势读数">第 {week} 周{metricLabel}：{groups.map(label => `${label} ${format(pointValue(label, week))}${unit}`).join("；")}。</p>
          </Stack></section>
          <section className="bm-d-insight" aria-labelledby="bm-d-insight-title"><p className="bm-d-ai-label">AI 洞察 · 示例</p><h2 id="bm-d-insight-title">把关注点带回下一次课堂</h2><p className="rain-type-reading">平均分与提交情况可作为回看作业的线索。建议先查看未提交的原因，再从典型作答中选择需要讨论的概念。</p><a href="#bm-c" data-focus="item">查看作答与评分 →</a><p className="bm-d-scope">示例解读，未调用 AI 服务。</p></section>
          </div>
          <section className="bm-d-details" aria-labelledby="bm-d-details-title"><Inline justify="between"><h2 id="bm-d-details-title">数据明细</h2><span className="bm-d-scope">每页 4 条 · 分页只改变明细</span></Inline>
            <DensityProvider density="compact"><TableScrollArea aria-label="报告明细滚动区"><Table><TableCaption>当前筛选范围的周度汇总，分页不改变关键指标。</TableCaption><TableHeader><TableRow><TableHead>周次</TableHead><TableHead>班级</TableHead><TableHead>应交</TableHead><TableHead>已交</TableHead><TableHead>平均分</TableHead><TableHead>提交率</TableHead></TableRow></TableHeader><TableBody>{rows.slice((page - 1) * 4, page * 4).map(row => <TableRow key={`${row.group}-${row.week}`}><TableCell>第 {row.week} 周</TableCell><TableCell>{row.group}</TableCell><TableCell>{row.expected}</TableCell><TableCell>{row.submitted}</TableCell><TableCell>{format(summarize([row]).average)}</TableCell><TableCell>{format(summarize([row]).completion)}%</TableCell></TableRow>)}</TableBody></Table></TableScrollArea>
            <Pagination total={rows.length} page={page} pageSize={4} showJumper={false} onChange={change => setPage(change.page)} aria-label="报告明细分页" /></DensityProvider>
          </section>
        </>}
      <footer className="bm-d-footer"><p>虚构教学数据 · 仅供报告布局与交互体验 · 字体使用本机已有字体</p><details><summary data-focus="item">演示设置</summary><Inline gap={16}><Checkbox label="下次加载失败" disabled={loadState === "loading"} checked={failLoad} onCheckedChange={setFailLoad} /><Button variant="tertiary" disabled={loadState === "loading"} onClick={() => { setEmpty(true); setPage(1); setLoadState("ready"); }}>预览空数据</Button></Inline></details></footer>
    </Stack></div>
  </main>;
}
