export const activityTypes = [
  { value: "discussion", label: "课堂研讨" },
  { value: "review", label: "案例复盘" },
  { value: "critique", label: "作品评议" },
];

export interface Activity {
  name: string;
  type: string;
  location: string;
  description: string;
  outline: string;
  capacityLimit: number | null;
}
export interface ActivityDraft extends Omit<Activity, "capacityLimit"> {
  limitEnabled: boolean;
  capacity: string;
}
export type ActivityErrors = Partial<Record<"name" | "type" | "location" | "description" | "capacity", string>>;

export const initialActivity: Activity = {
  name: "用户访谈研讨",
  type: "discussion",
  location: "设计楼 201 研讨室",
  description: "围绕校园学习空间的使用体验，分享小组用户访谈中的发现。\n\n结合访谈记录，讨论如何从真实需求中形成有依据的设计判断。",
  outline: "1. 分享一条最有启发的访谈记录\n2. 区分观察事实与个人推测\n3. 确定下一步需要验证的问题",
  capacityLimit: null,
};

export function toDraft({ capacityLimit, ...activity }: Activity): ActivityDraft {
  return { ...activity, limitEnabled: capacityLimit !== null, capacity: capacityLimit === null ? "" : String(capacityLimit) };
}

export function validateActivity(draft: ActivityDraft): ActivityErrors {
  const errors: ActivityErrors = {};
  if (!draft.name.trim()) errors.name = "请填写活动名称。";
  if (!activityTypes.some(type => type.value === draft.type)) errors.type = "请选择活动类型。";
  if (!draft.location.trim()) errors.location = "请填写活动地点。";
  if (!draft.description.trim()) errors.description = "请填写活动说明。";
  const capacity = Number(draft.capacity);
  if (draft.limitEnabled && (!draft.capacity.trim() || !Number.isInteger(capacity) || capacity < 1 || capacity > 200)) {
    errors.capacity = "请输入 1–200 之间的整数。";
  }
  return errors;
}

/** Call after validation. Hidden draft input is deliberately excluded from the saved object. */
export function toActivity(draft: ActivityDraft): Activity {
  return {
    name: draft.name.trim(), type: draft.type, location: draft.location.trim(),
    description: draft.description.trim(), outline: draft.outline.trim(),
    capacityLimit: draft.limitEnabled ? Number(draft.capacity) : null,
  };
}
