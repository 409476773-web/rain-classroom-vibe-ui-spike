import { useEffect, useId, useRef, useState, type FormEvent } from "react";
import { Grid, Inline, Stack } from "@rain-next/layouts";
import { AlertDialog, Button, Card, CardContent, CardHeader, CardTitle, Checkbox, Dialog, FormItem, IconButton, Input, RadioGroup, Textarea, defineRainLocalRecipe, type DialogLocalRecipe } from "@rain-next/ui";
import { CloseBoldIcon } from "@rain-next/ui/icons/close-bold";
import { simulateTask } from "../bm-b/state";
import { activityTypes, initialActivity, toActivity, toDraft, validateActivity, type ActivityDraft, type ActivityErrors } from "./state";
import "./page.css";

const recipe: DialogLocalRecipe = defineRainLocalRecipe({
  id: "activity-edit-dialog", origin: "ui-dialog", scope: "feature",
  classes: { content: "activity-dialog", body: "activity-body p-rain-12", footer: "activity-footer" },
  modifiedParts: ["content", "body", "footer"], candidateTokens: [], promotionStatus: "not-proposed",
});

export function ActivityScenario() {
  const [saved, setSaved] = useState(initialActivity);
  const [draft, setDraft] = useState(() => toDraft(initialActivity));
  const [open, setOpen] = useState(false), [saving, setSaving] = useState(false);
  const [confirmDiscard, setConfirmDiscard] = useState(false), [failNextSave, setFailNextSave] = useState(false);
  const [errors, setErrors] = useState<ActivityErrors>({});
  const [saveError, setSaveError] = useState(""), [notice, setNotice] = useState("");
  const formId = useId(), nameRef = useRef<HTMLInputElement>(null), safeAction = useRef<HTMLButtonElement>(null);
  const formRef = useRef<HTMLFormElement>(null), errorRef = useRef<HTMLParagraphElement>(null);
  const requestRef = useRef<AbortController | null>(null);
  const pendingNavigation = useRef<NavigationDestination | null>(null), allowNavigation = useRef(false);
  const dirty = JSON.stringify(draft) !== JSON.stringify(toDraft(saved));
  useEffect(() => () => { requestRef.current?.abort(); }, []);
  useEffect(() => { if (saveError) errorRef.current?.focus(); }, [saveError]);
  useEffect(() => {
    if (!open || (!dirty && !saving)) return;
    const protectDraft = (event: BeforeUnloadEvent) => { event.preventDefault(); event.returnValue = ""; };
    addEventListener("beforeunload", protectDraft);
    return () => removeEventListener("beforeunload", protectDraft);
  }, [open, dirty, saving]);
  useEffect(() => {
    // ponytail: local hash protection uses Navigation API; add a legacy fallback only if that browser support is required.
    if (!open || !window.navigation) return;
    const protectNavigation = (event: NavigateEvent) => {
      if (!event.destination.sameDocument || new URL(event.destination.url).hash === location.hash) return;
      if (allowNavigation.current) { allowNavigation.current = false; return; }
      if (!requestRef.current && !dirty) return;
      event.preventDefault();
      if (!requestRef.current) { pendingNavigation.current = event.destination; setConfirmDiscard(true); }
    };
    window.navigation.addEventListener("navigate", protectNavigation);
    return () => window.navigation.removeEventListener("navigate", protectNavigation);
  }, [open, dirty]);

  function change<K extends keyof ActivityDraft>(key: K, value: ActivityDraft[K]) {
    setDraft(current => ({ ...current, [key]: value }));
    setErrors(current => ({ ...current, [key === "limitEnabled" ? "capacity" : key]: undefined }));
  }
  function discard() {
    const destination = pendingNavigation.current;
    pendingNavigation.current = null;
    setDraft(toDraft(saved)); setOpen(false); setNotice("已取消修改，活动信息保持不变。");
    if (destination) {
      allowNavigation.current = true;
      if (destination.key) {
        const navigation = window.navigation.traverseTo(destination.key);
        void Promise.all([navigation.committed, navigation.finished]).catch(() => {
          allowNavigation.current = false; setNotice("页面跳转未完成，请重新选择。");
        });
      } else location.hash = new URL(destination.url).hash;
    }
  }
  async function save(event: FormEvent) {
    event.preventDefault();
    if (requestRef.current) return;
    const nextErrors = validateActivity(draft);
    setErrors(nextErrors); setSaveError("");
    const firstError = Object.keys(nextErrors)[0];
    if (firstError) {
      formRef.current?.querySelector<HTMLElement>(`[name="${firstError}"]`)?.focus();
      return;
    }
    const request = new AbortController(), submitted = toActivity(draft);
    requestRef.current = request; setSaving(true); setFailNextSave(false);
    try {
      await simulateTask(request.signal, failNextSave);
      if (request.signal.aborted || requestRef.current !== request) return;
      setSaved(submitted); setDraft(toDraft(submitted)); setOpen(false); setNotice("活动信息已保存。");
    } catch {
      if (request.signal.aborted || requestRef.current !== request) return;
      setSaveError("保存失败，填写内容已保留。请重试。");
    } finally {
      if (requestRef.current === request && !request.signal.aborted) { requestRef.current = null; setSaving(false); }
    }
  }

  return <section className="activity-scenario" data-rain-id="scenario-activity" data-asset-identity="local-experiment" aria-label="研讨活动">
    <p className="activity-course">设计方法与实践</p>
    <Dialog.Root open={open} onOpenChange={(next, details) => {
      if (requestRef.current) { details.cancel(); return; }
      if (!next) {
        if (dirty) { details.cancel(); setConfirmDiscard(true); } else discard();
        return;
      }
      setDraft(toDraft(saved)); setErrors({}); setSaveError(""); setNotice(""); setOpen(true);
    }}>
      <Card>
        <CardHeader><Inline justify="between" gap={16}>
          <CardTitle as="h2">{saved.name}</CardTitle>
          <Dialog.Trigger render={<Button variant="primary">编辑活动</Button>} />
        </Inline></CardHeader>
        <CardContent><Stack gap={24}>
          <dl className="activity-facts">
            <div><dt>活动类型</dt><dd>{activityTypes.find(type => type.value === saved.type)?.label}</dd></div>
            <div><dt>地点</dt><dd>{saved.location}</dd></div>
            <div><dt>报名人数</dt><dd>{saved.capacityLimit === null ? "不限人数" : `最多 ${saved.capacityLimit} 人`}</dd></div>
          </dl>
          <section aria-labelledby={`${formId}-saved-description`}><h3 id={`${formId}-saved-description`}>活动说明</h3>
            <p className="activity-reading" data-slot="saved-description">{saved.description}</p></section>
          <section aria-labelledby={`${formId}-saved-outline`}><h3 id={`${formId}-saved-outline`}>讨论提纲</h3>
            <p className="activity-reading" data-slot="saved-outline">{saved.outline || "未填写"}</p></section>
        </Stack></CardContent>
      </Card>
      <Dialog.Content width={816} initialFocus={nameRef} localRecipe={recipe} aria-busy={saving}>
        <Dialog.Header>
          <Inline justify="between" align="start" wrap={false} gap={16}>
            <Dialog.Title>编辑研讨活动</Dialog.Title>
            <Dialog.Close render={<IconButton size="28/20" icon={<CloseBoldIcon />} disabled={saving} aria-label="关闭活动编辑" />} />
          </Inline>
          <Dialog.Description>设计方法与实践 · 完善活动安排后保存。</Dialog.Description>
        </Dialog.Header>
        <Dialog.Body>
          <form id={formId} ref={formRef} onSubmit={save} noValidate aria-label="研讨活动表单" aria-busy={saving}>
            <Stack gap={12}>
              <section aria-labelledby={`${formId}-basic`}><h3 id={`${formId}-basic`}>基本信息</h3><Stack gap={20}>
                <Grid columns={2} minColumnWidth={240} gap={20}>
                  <FormItem label="活动名称" required disabled={saving} status={errors.name ? "error" : "default"} message={errors.name}>
                    <Input ref={nameRef} name="name" value={draft.name} onValueChange={value => change("name", value)} />
                  </FormItem>
                  <FormItem label="地点" required disabled={saving} status={errors.location ? "error" : "default"} message={errors.location}>
                    <Input name="location" value={draft.location} onValueChange={value => change("location", value)} />
                  </FormItem>
                </Grid>
                <RadioGroup legend="活动类型" name="type" orientation="horizontal" required options={activityTypes} value={draft.type || null}
                  onValueChange={value => change("type", value)} disabled={saving} invalid={Boolean(errors.type)} message={errors.type} />
              </Stack></section>
              <section aria-labelledby={`${formId}-content`}><h3 id={`${formId}-content`}>研讨内容</h3><Stack gap={20}>
                <FormItem label="活动说明" required disabled={saving} status={errors.description ? "error" : "default"} message={errors.description} help="介绍本次活动的主题、目标与参与准备。">
                  <Textarea name="description" value={draft.description} onValueChange={value => change("description", value)} rows={4} />
                </FormItem>
                <FormItem label="讨论提纲（选填）" disabled={saving} help="可按讨论顺序分段填写。">
                  <Textarea name="outline" value={draft.outline} onValueChange={value => change("outline", value)} rows={4} />
                </FormItem>
              </Stack></section>
              <section aria-labelledby={`${formId}-registration`}><h3 id={`${formId}-registration`}>报名设置</h3><Stack gap={16}>
                <Checkbox label="限制报名人数" description="未开启时，不限制报名人数。" checked={draft.limitEnabled} onCheckedChange={value => change("limitEnabled", value)} disabled={saving} />
                {draft.limitEnabled && <div className="activity-capacity-field">
                  <label htmlFor={`${formId}-capacity`}>报名人数上限 <span aria-hidden="true" className="activity-error">*</span></label>
                  <Inline gap={8}>
                    <input id={`${formId}-capacity`} className="activity-capacity" data-focus="control" name="capacity" type="number" inputMode="numeric" min={1} max={200} step={1}
                      value={draft.capacity} onChange={event => change("capacity", event.currentTarget.value)} required disabled={saving}
                      aria-invalid={Boolean(errors.capacity)} aria-describedby={`${formId}-capacity-help${errors.capacity ? ` ${formId}-capacity-error` : ""}`} />
                    <span>人</span>
                  </Inline>
                  <p id={`${formId}-capacity-help`} className="activity-supporting">填写 1–200 之间的整数。</p>
                  {errors.capacity && <p id={`${formId}-capacity-error`} className="activity-error">{errors.capacity}</p>}
                </div>}
              </Stack></section>
            </Stack>
          </form>
        </Dialog.Body>
        <Dialog.Footer divider>
          <div className="activity-feedback">{saveError
            ? <p ref={errorRef} tabIndex={-1} role="alert" className="activity-error">{saveError}</p>
            : <p role="status">{saving ? "正在保存，请稍候…" : "修改将在保存后生效"}</p>}</div>
          <Inline gap={12} className="activity-actions">
            <Dialog.Close render={<Button variant="secondary" disabled={saving}>取消</Button>} />
            <Button type="submit" form={formId} variant="primary" loading={saving} disabled={saving}>{saveError ? "重试保存" : "保存活动"}</Button>
          </Inline>
        </Dialog.Footer>
        <AlertDialog.Root open={confirmDiscard} onOpenChange={next => { setConfirmDiscard(next); if (!next) pendingNavigation.current = null; }}>
          <AlertDialog.Content initialFocus={safeAction}>
            <AlertDialog.Header><AlertDialog.Title>放弃活动修改？</AlertDialog.Title>
              <AlertDialog.Description>本轮未保存的内容将丢失，已保存的活动信息不受影响。</AlertDialog.Description></AlertDialog.Header>
            <AlertDialog.Footer>
              <AlertDialog.Close render={<Button ref={safeAction} variant="secondary">继续编辑</Button>} />
              <Button variant="primary" tone="danger" onClick={() => { setConfirmDiscard(false); discard(); }}>放弃修改</Button>
            </AlertDialog.Footer>
          </AlertDialog.Content>
        </AlertDialog.Root>
      </Dialog.Content>
    </Dialog.Root>
    <p role="status" className="activity-notice">{notice}</p>
    <details className="activity-demo"><summary>演示选项</summary>
      <Checkbox label="模拟下次保存失败" checked={failNextSave} onCheckedChange={setFailNextSave} />
    </details>
    <p className="activity-note">虚构课程与活动 · 仅在当前页面内存中保存，刷新页面后恢复初始信息。</p>
  </section>;
}
