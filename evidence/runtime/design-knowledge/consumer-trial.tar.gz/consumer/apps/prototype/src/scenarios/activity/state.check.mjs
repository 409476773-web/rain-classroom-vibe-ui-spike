import assert from 'node:assert/strict';
import { test } from 'node:test';
import { initialActivity, toDraft, toActivity, validateActivity } from './state.ts';

test('required fields reject blank input and unknown activity types', () => {
  const draft = toDraft(initialActivity);
  assert.deepEqual(validateActivity(draft), {});
  for (const field of ['name', 'location', 'description']) {
    assert.ok(validateActivity({ ...draft, [field]: ' \n ' })[field], `${field} must be required`);
  }
  for (const type of ['', 'unknown']) assert.ok(validateActivity({ ...draft, type }).type);
  assert.deepEqual(validateActivity({ ...draft, outline: '' }), {});
});

test('capacity accepts only finite integer values from 1 to 200 when enabled', () => {
  const draft = { ...toDraft(initialActivity), limitEnabled: true };
  for (const capacity of ['1', '24', '200', '1.0']) {
    assert.deepEqual(validateActivity({ ...draft, capacity }), {}, `${capacity} is an integer in range`);
  }
  for (const capacity of ['', ' ', '0', '-1', '201', '1.5', 'abc', 'Infinity']) {
    assert.ok(validateActivity({ ...draft, capacity }).capacity, `${capacity} must be rejected`);
    assert.deepEqual(validateActivity({ ...draft, capacity, limitEnabled: false }), {}, 'hidden limit must not block saving');
  }
});

test('draft edits never mutate saved information; submission normalizes only outer whitespace', () => {
  const saved = { ...initialActivity };
  const draft = toDraft(saved);
  draft.name = '  更新后的活动  ';
  draft.description = ' 第一段\n\n第二段 ';
  draft.outline = ' 问题一\n问题二 ';
  draft.limitEnabled = true;
  draft.capacity = '200';
  const submitted = toActivity(draft);
  assert.deepEqual(saved, initialActivity);
  assert.equal(submitted.name, '更新后的活动');
  assert.equal(submitted.description, '第一段\n\n第二段');
  assert.equal(submitted.outline, '问题一\n问题二');
  assert.equal(submitted.capacityLimit, 200);
  assert.equal(draft.name, '  更新后的活动  ');
  assert.equal(toActivity({ ...draft, limitEnabled: false, capacity: 'invalid' }).capacityLimit, null);
});

test('opening a saved limited activity restores its cap; unlimited starts a fresh empty cap', () => {
  assert.deepEqual(
    [toDraft({ ...initialActivity, capacityLimit: 1 }).limitEnabled, toDraft({ ...initialActivity, capacityLimit: 1 }).capacity],
    [true, '1'],
  );
  assert.deepEqual([toDraft(initialActivity).limitEnabled, toDraft(initialActivity).capacity], [false, '']);
});
