# Rain Next 本地原型

生成或修改页面前，先读 [原型设计指南](docs/ai/prototype-design.md)，再按任务读取组合、参考图和组件合同；按指南保存设计依据、首稿和实际检查。

默认 Prototype Mode：共享 packages 与锁文件保持只读，优先已有 Variant、页面 Local Recipe、Local Fork。业务状态由页面持有；不扩大旧视觉接受，不自动发布、迁移、写入 Figma 或执行 Git 操作。用户的新任务指令优先。
