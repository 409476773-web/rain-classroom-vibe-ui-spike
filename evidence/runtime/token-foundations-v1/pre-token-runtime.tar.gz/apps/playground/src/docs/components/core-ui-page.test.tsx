import { render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it } from "vitest";

import { CoreUiPage } from "./core-ui-page";

describe("CoreUiPage", () => {
  it("documents exactly four prototype-ready local candidates", () => {
    const { container } = render(<CoreUiPage />);
    expect(screen.getByRole("heading", { level: 1, name: "Core UI，把高频动作先做准" })).toHaveAttribute(
      "id",
      "core-ui-title",
    );
    const page = container.querySelector('[data-rain-id="core-ui-page"]');
    expect(page).toHaveAttribute("data-asset-identity", "local-experiment");
    expect(page).toHaveAttribute("data-maturity", "prototype-ready");
    expect(container.querySelectorAll('[data-slot="family-contract"]')).toHaveLength(4);
    expect(screen.getAllByText("prototype-ready")).toHaveLength(4);
  });

  it("uses plain-language contracts for every family", () => {
    render(<CoreUiPage />);
    for (const label of [
      "适合用在",
      "不适合",
      "外观与状态",
      "密度",
      "结构",
      "无障碍",
      "参考成熟库",
      "Rain 来源",
      "修改边界",
    ]) {
      expect(screen.getAllByText(label)).toHaveLength(4);
    }
  });

  it("shows the complete confirmed Button matrix for designer review", () => {
    const { container } = render(<CoreUiPage />);
    const buttonFamily = container.querySelector('[data-rain-id="core-ui-button"]');
    expect(buttonFamily).not.toBeNull();

    for (const demo of [
      "hierarchy",
      "sizes",
      "danger",
      "loading",
      "disabled",
      "focus-states",
      "width-and-label",
    ]) {
      expect(
        buttonFamily?.querySelector(`[data-button-demo="${demo}"]`),
      ).toBeInTheDocument();
    }

    for (const size of ["mini", "small", "medium", "large", "xl"]) {
      expect(
        buttonFamily?.querySelector(`[data-rain-id="ui-button"][data-size="${size}"]`),
      ).toBeInTheDocument();
    }

    expect(within(buttonFamily as HTMLElement).getByRole("button", { name: "保存草稿" }))
      .toHaveAttribute("data-variant", "tertiary");
    expect(within(buttonFamily as HTMLElement).getByRole("button", { name: "删除课程" }))
      .toHaveAttribute("data-variant", "tertiary");
    expect(within(buttonFamily as HTMLElement).getByRole("button", { name: "确认永久删除" }))
      .toHaveAttribute("data-variant", "primary");
    expect(
      buttonFamily?.querySelector('[data-rain-id="ui-button"][data-block="true"]'),
    ).toBeInTheDocument();
  });

  it("keeps Input labels and messages outside the public Input root", () => {
    const { container } = render(<CoreUiPage />);
    const errorInput = screen.getByRole("textbox", { name: "教材编号" });
    const root = errorInput.closest('[data-rain-id="ui-input"]');
    expect(root).toHaveAttribute("data-status", "error");
    expect(root?.querySelector("label")).toBeNull();
    expect(root?.querySelector('[data-slot="message"]')).toBeNull();
    expect(errorInput).toHaveAttribute("aria-describedby", "core-course-code-message");
    expect(container.querySelector("#core-course-code-message")).toHaveTextContent("该编号已存在");
  });

  it("shows Badge attachments without calling them status badges", () => {
    const { container } = render(<CoreUiPage />);
    expect(container.querySelectorAll('[data-rain-id="ui-badge"]')).toHaveLength(4);
    expect(container.querySelector('[data-type="dot"]')).toBeInTheDocument();
    expect(container.querySelectorAll('[data-type="count"]')).toHaveLength(2);
    expect(container.querySelector('[data-type="label"]')).toBeInTheDocument();
    expect(screen.queryByText("STATUS BADGES")).toBeNull();
    expect(screen.getByText(/命名状态不由普通 Badge 承担/)).toBeVisible();
    expect(screen.getByText("资源更新")).toHaveAccessibleName(
      "资源更新，3 条更新",
    );
  });

  it("keeps the removable Tag interaction real and text-based", async () => {
    const user = userEvent.setup();
    render(<CoreUiPage />);
    const fixture = screen.getByTestId("removable-tag-fixture");
    const remove = within(fixture).getByRole("button", { name: "移除标签 重点" });
    expect(remove).toHaveTextContent("移除");
    await user.click(remove);
    expect(screen.queryByTestId("removable-tag-fixture")).toBeNull();
  });

  it("keeps the preview free of unregistered icon substitutes", () => {
    const { container } = render(<CoreUiPage />);
    expect(container.querySelectorAll("svg")).toHaveLength(0);
    expect(container.textContent).not.toMatch(/[\u00d7✕✖✗✘]/u);
  });

  it("separates the accepted Button Gate from the unevaluated overall Human Gate", () => {
    render(<CoreUiPage />);
    expect(screen.getByText("BUTTON ACCEPTED")).toBeInTheDocument();
    expect(screen.getByText(/Implementation: completed/)).toHaveTextContent(
      "Automated verification: passed · Overall Human Gate: not-evaluated · Button: accepted · Input / Tag / Badge / Surface / Card: not-evaluated",
    );
  });
});
