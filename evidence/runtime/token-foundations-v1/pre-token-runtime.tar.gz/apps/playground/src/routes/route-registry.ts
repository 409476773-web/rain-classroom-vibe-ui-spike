export type OverviewRoute = {
  id: "foundations" | "components" | "icons" | "benchmarks";
  label: "Foundations" | "Components" | "Icons" | "Benchmarks";
  href: "#foundations" | "#components" | "#icons" | "#benchmarks";
  description: string;
  meta: string;
};

export const overviewRoutes: readonly OverviewRoute[] = [
  {
    id: "foundations",
    label: "Foundations",
    href: "#foundations",
    description: "检查语义色、字体、密度、Focus 与 Motion 的 Day 2 合同。",
    meta: "42 个语义色角色",
  },
  {
    id: "components",
    label: "Components",
    href: "#components",
    description: "检查 Button、Input、Tag/Badge、Surface/Card 四个 Day 3 基础家族。",
    meta: "4 个家族",
  },
  {
    id: "benchmarks",
    label: "Benchmarks",
    href: "#benchmarks",
    description: "四类真实业务切片已登记，目前仅提供验证入口。",
    meta: "4 个已登记",
  },
  {
    id: "icons",
    label: "Icons",
    href: "#icons",
    description: "按用途查找图标，查看默认选择、配色与使用示例。",
    meta: "雨课堂完整图标目录",
  },
];
