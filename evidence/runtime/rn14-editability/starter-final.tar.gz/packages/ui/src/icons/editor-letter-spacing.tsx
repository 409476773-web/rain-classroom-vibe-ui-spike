// Generated from the frozen Figma inventory. Do not redraw or edit.
import { forwardRef } from "react";
import { Icon, type IconAsset, type IconProps } from "../icon/icon";

const asset: IconAsset = { assetId: "icon/editor-letter-spacing", src: new URL("./assets/editor-letter-spacing.svg", import.meta.url).href, colorMode: "host", rendering: "svg-mask" };

export const EditorLetterSpacingIcon = forwardRef<HTMLSpanElement, Omit<IconProps, "asset">>(function EditorLetterSpacingIcon(props, ref) {
  return <Icon {...props} ref={ref} asset={asset} />;
});
