// Generated from the frozen Figma inventory. Do not redraw or edit.
import { forwardRef } from "react";
import { Icon, type IconAsset, type IconProps } from "../icon/icon";

const asset: IconAsset = { assetId: "icon/file-format-txt-outline", src: new URL("./assets/file-format-txt-outline.svg", import.meta.url).href, colorMode: "intrinsic", rendering: "image" };

export const FileFormatTxtOutlineIcon = forwardRef<HTMLSpanElement, Omit<IconProps, "asset">>(function FileFormatTxtOutlineIcon(props, ref) {
  return <Icon {...props} ref={ref} asset={asset} />;
});
