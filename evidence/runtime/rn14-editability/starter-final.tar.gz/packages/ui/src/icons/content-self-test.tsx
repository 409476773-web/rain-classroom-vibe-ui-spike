// Generated from the frozen Figma inventory. Do not redraw or edit.
import { forwardRef } from "react";
import { Icon, type IconAsset, type IconProps } from "../icon/icon";

const asset: IconAsset = { assetId: "icon/content-self-test", src: new URL("./assets/content-self-test.svg", import.meta.url).href, colorMode: "host", rendering: "svg-mask" };

export const ContentSelfTestIcon = forwardRef<HTMLSpanElement, Omit<IconProps, "asset">>(function ContentSelfTestIcon(props, ref) {
  return <Icon {...props} ref={ref} asset={asset} />;
});
