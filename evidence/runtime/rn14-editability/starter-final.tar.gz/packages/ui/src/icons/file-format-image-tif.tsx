// Generated from the frozen Figma inventory. Do not redraw or edit.
import { forwardRef } from "react";
import { Icon, type IconAsset, type IconProps } from "../icon/icon";

const asset: IconAsset = { assetId: "icon/file-format-image-tif", src: new URL("./assets/file-format-image-tif.svg", import.meta.url).href, colorMode: "intrinsic", rendering: "image" };

export const FileFormatImageTifIcon = forwardRef<HTMLSpanElement, Omit<IconProps, "asset">>(function FileFormatImageTifIcon(props, ref) {
  return <Icon {...props} ref={ref} asset={asset} />;
});
