# Rain Next RN-14 本地试用样本

BM-A/B复用生成与两轮结构改造的固定源码快照，全部为local-experiment。数据、保存和上传为本地模拟。新样本视觉尚待人工确认，原有颜色、IME、读屏和触屏限制仍保留；未发布或接入业务。

使用当前锁定pnpm版本运行：

```
pnpm install --frozen-lockfile --offline --ignore-scripts --package-import-method=copy
pnpm build
pnpm dev --port 5315 --strictPort
```

本机缓存缺失时离线安装会失败；另一台机器尚未实测。打开 /#bm-a 或 /#bm-b，页头可切换场景。source-lock.json 区分原始HEAD、内容快照和本地修改，不将未提交内容冒称为Commit版本。

浏览器检查：从本目录运行 `node rn14-browser.mjs http://127.0.0.1:5315 /tmp/rn14-browser-check final chromium`；也支持firefox/webkit。请先启动上述本地服务。浏览器工具依赖来自本目录，浏览器可执行文件使用Playwright本机缓存。
