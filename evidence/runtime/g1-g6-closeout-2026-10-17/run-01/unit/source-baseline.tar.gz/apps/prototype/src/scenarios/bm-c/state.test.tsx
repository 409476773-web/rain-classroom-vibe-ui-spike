import { act, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { expect, it } from "vitest";
import { answers, filterAnswers, groupSequence, initialGrades, scoreError } from "./state";
import { GradingWorkbenchScenario } from "./page";

it("keeps paper and parent boundaries, distinguishes zero scores and filters answer records", () => {
  const current = answers[0]!, visible = filterAnswers("A", "all", "", initialGrades);
  expect(visible).toHaveLength(18);
  expect(groupSequence(current, "question", visible).map(answer => answer.id)).toEqual(["A-1-1", "A-2-1", "A-3-1", "A-4-1", "A-5-1", "A-6-1"]);
  expect(groupSequence(current, "student", visible).map(answer => answer.id)).toEqual(["A-1-1", "A-1-2", "A-1-3"]);
  expect(groupSequence(current, "student", answers).every(answer => answer.paper === "A")).toBe(true);
  expect(filterAnswers("A", "unanswered", "", initialGrades).map(answer => answer.id)).toEqual(["A-6-3"]);
  expect(filterAnswers("B", "all", "学生 02", {}).map(answer => answer.id)).toEqual(["B-2-1", "B-2-2", "B-2-3"]);
  const zero = { "A-1-1": { score: 0, comment: "" } };
  expect(filterAnswers("A", "graded", "", zero).map(answer => answer.id)).toEqual(["A-1-1"]);
  expect(filterAnswers("A", "pending", "", zero).some(answer => answer.id === "A-1-1" || !answer.text)).toBe(false);
  for (const invalid of ["", " ", "abc", "1e1", "-1", "10.5", "0.25", "Infinity"]) expect(scoreError(invalid, 10), invalid).not.toBe("");
  for (const valid of ["0", "0.5", "9.5", "10"]) expect(scoreError(valid, 10)).toBe("");
});

it("preserves drafts, blocks duplicate saves and navigation, stays on failure and advances only after retry", async () => {
  const user = userEvent.setup(); let reject!: (error: Error) => void, calls = 0;
  const first = new Promise<void>((_resolve, fail) => { reject = fail; });
  render(<GradingWorkbenchScenario saveTask={() => ++calls === 1 ? first : Promise.resolve()} />);
  await user.click(screen.getByRole("button", { name: "保存并下一位" }));
  expect(screen.getByRole("textbox", { name: "本题得分" })).toHaveFocus(); expect(calls).toBe(0);
  expect(screen.getByRole("status")).toHaveTextContent("尚未评分");
  await user.type(screen.getByRole("textbox", { name: "本题得分" }), "8.5");
  expect(screen.getByRole("status")).toHaveTextContent("草稿待保存");
  await user.type(screen.getByRole("textbox", { name: "评语" }), "注意适用条件");
  await user.click(screen.getByRole("button", { name: "下一位" }));
  expect(screen.getByRole("textbox", { name: "本题得分" })).toHaveValue("");
  await user.click(screen.getByRole("button", { name: "上一位" }));
  expect(screen.getByRole("textbox", { name: "本题得分" })).toHaveValue("8.5");
  expect(screen.getByRole("textbox", { name: "评语" })).toHaveValue("注意适用条件");
  await user.click(screen.getByRole("tab", { name: "按人批改" }));
  expect(screen.getByRole("heading", { name: "示例学生 01 · 第 1 题" })).toBeInTheDocument();
  await user.click(screen.getByRole("button", { name: "保存并下一题" }));
  expect(screen.getByRole("button", { name: "下一题" })).toBeDisabled();
  expect(screen.getByRole("radio", { name: "B 卷" })).toBeDisabled();
  await user.click(screen.getByRole("button", { name: "保存并下一题" })); expect(calls).toBe(1);
  await act(async () => reject(new Error("offline")));
  expect(await screen.findByRole("alert")).toHaveTextContent("保存失败");
  expect(screen.getByRole("status")).toHaveTextContent("保存失败");
  expect(screen.getByRole("alert")).toHaveFocus();
  expect(screen.getByRole("heading", { name: "示例学生 01 · 第 1 题" })).toBeInTheDocument();
  expect(screen.getByRole("textbox", { name: "本题得分" })).toHaveValue("8.5");
  await user.click(screen.getByRole("button", { name: "重试并下一题" }));
  expect(await screen.findByRole("heading", { name: "示例学生 01 · 第 2 题" })).toHaveFocus();
  await user.click(screen.getByRole("button", { name: "上一题" }));
  expect(screen.getByRole("textbox", { name: "本题得分" })).toHaveValue("8.5");
});

it("aborts an unfinished save on unmount", async () => {
  const user = userEvent.setup(); let signal!: AbortSignal;
  const view = render(<GradingWorkbenchScenario saveTask={next => { signal = next; return new Promise(() => {}); }} />);
  await user.type(screen.getByRole("textbox", { name: "本题得分" }), "0");
  await user.click(screen.getByRole("button", { name: "保存" }));
  view.unmount(); expect(signal.aborted).toBe(true);
});

it("opens a new parent at its first pending answer and restores a previously visited parent", async () => {
  const user = userEvent.setup(); render(<GradingWorkbenchScenario />);
  await user.click(screen.getByRole("button", { name: "选择 示例学生 04 第 1 题" }));
  await user.click(screen.getByText("第 2 题 · 能量转化", { selector: "summary > span" }));
  expect(screen.getByRole("heading", { name: "示例学生 01 · 第 2 题" })).toBeInTheDocument();
  await user.click(screen.getByRole("button", { name: "选择 示例学生 05 第 2 题" }));
  await user.click(screen.getByText("第 1 题 · 运动与受力", { selector: "summary > span" }));
  expect(screen.getByRole("heading", { name: "示例学生 04 · 第 1 题" })).toBeInTheDocument();
});

it("keeps search focus while typing changes the selected answer", async () => {
  const user = userEvent.setup(); render(<GradingWorkbenchScenario />);
  const search = screen.getByRole("textbox", { name: "查找批改对象" });
  await user.type(search, "第 2 题");
  expect(search).toHaveValue("第 2 题");
  expect(search).toHaveFocus();
  expect(screen.getByRole("heading", { name: "示例学生 01 · 第 2 题" })).toBeInTheDocument();
});
