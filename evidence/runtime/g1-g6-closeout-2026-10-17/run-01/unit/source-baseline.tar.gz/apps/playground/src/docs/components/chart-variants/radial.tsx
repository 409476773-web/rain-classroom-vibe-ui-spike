import { useId, useMemo, useState } from "react";
import {
  PatternLines, PieChart, PieSlice, PieCenter, RingChart, Ring, RingCenter, ChartLegend,
  Legend, LegendItemComponent, LegendMarker, LegendLabel, LegendValue, LegendProgress, useLegendItem,
  RadarChart, RadarGrid, RadarAxis, RadarArea, RadarLabels,
  type PieData, type RingData, type RadarData, type RadarMetric,
} from "@rain-next/ui/charts";
import { ExampleLegend, immediate, seriesColors, useVariantSetting, VariantTable, type VariantExampleProps } from "./shared";
import { exampleLabel, applyPieBoundary, applyRingBoundary, type ChartBoundaryScenario } from "../chart-data";

export const RADIAL_VARIANT_IDS = [
  "pie-default", "pie-donut", "pie-legend", "pie-patterns", "pie-gradients",
  "pie-grow-hover", "pie-custom-center", "pie-donut-patterns", "pie-donut-grow-hover",
  "radar-default", "radar-triangle", "radar-hexagon", "radar-single-series", "radar-minimal", "radar-grid-only",
  "ring-default", "ring-flat-caps", "ring-thick-rings", "ring-three-quarter", "ring-half-circle", "ring-legend",
] as const;

type KeyItem = { label: string; value: number; color?: string; maxValue?: number };
function RingLegendItem() {
  const { item } = useLegendItem();
  const applicable = Number.isFinite(item.maxValue) && item.maxValue! > 0;
  const overflow = applicable && item.value > item.maxValue!;
  const percentage = applicable ? `${(item.value / item.maxValue! * 100).toFixed(1)}%` : "不适用";
  return <LegendItemComponent className="rain-chart-progress-legend-item">
    <button type="button" className="rain-chart-progress-legend-heading"
      aria-label={`${item.label} ${item.value}/${item.maxValue} · ${percentage}${overflow ? " · 超目标" : ""}`}>
      <LegendMarker /><LegendLabel />
      <LegendValue showPercentage={applicable} formatValue={value => `${value}/${item.maxValue} ·`} formatPercentage={value => `${value.toFixed(1)}%`} />
      {!applicable && <span>不适用</span>}{overflow && <span>超目标</span>}
    </button>
    {applicable && !overflow && <LegendProgress />}
  </LegendItemComponent>;
}
function InteractiveKey({ items, hovered, onHover, progress = false }: {
  items: KeyItem[]; hovered: number | null; onHover: (index: number | null) => void; progress?: boolean;
}) {
  if (progress) return <Legend className="rain-chart-progress-legend" items={items.map(item => ({ ...item, color: item.color ?? seriesColors[0]! }))} hoveredIndex={hovered} onHoverChange={onHover}>
    <RingLegendItem />
  </Legend>;
  return <ChartLegend className="rain-chart-variant-legend" items={items.map(item=>({...item,color:item.color??seriesColors[0]!}))} hoveredIndex={hovered} onHover={onHover} showValue={false}
    renderItem={({item,isHovered})=><button type="button"
      className="rain-chart-variant-legend-item" data-active={isHovered || undefined}>
      <span className="rain-chart-legend-dot" aria-hidden="true" style={{ background: item.color }} />
      <span>{item.label}</span>
      <span>{`${item.value} 人`}</span>
    </button>} />;
}

function PieVariant(props: VariantExampleProps) {
  const { variantId, revision, replay, reduced, active } = props;
  const instanceId = useId().replace(/:/g, "");
  const [hoveredKey, setHoveredKey] = useState<string | null>(null);
  const [state, setState] = useVariantSetting("state", "normal", props);
  const [chosenScenario, setScenario] = useVariantSetting("boundaryScenario", "normal", props);
  const scenario = state !== "zero" && chosenScenario.startsWith("pie-") ? chosenScenario : "normal";
  const pattern = variantId === "pie-patterns" || variantId === "pie-donut-patterns";
  const gradient = variantId === "pie-gradients";
  const grow = variantId.endsWith("grow-hover");
  const custom = variantId === "pie-custom-center";
  const donut = variantId.includes("donut") || variantId === "pie-legend" || custom;
  const data = useMemo<PieData[]>(() => {
    const values = (gradient
      ? [[40, 30, 30], [52, 27, 21], [44, 38, 18]]
      : pattern ? [[35, 25, 20, 20], [46, 28, 17, 9], [39, 34, 19, 8]]
      : [[186, 142, 98, 74], [202, 118, 76, 64], [174, 151, 87, 68]])[revision % 3]!;
    return applyPieBoundary(values.map((value, index) => ({ label: exampleLabel(["讲授课", "研讨课", "实验课", "实践课"][index]!, state), value: state === "zero" ? 0 : value, color: seriesColors[index]! })),state === "zero" ? "normal" : scenario);
  }, [gradient, pattern, revision, state,scenario]);
  const total = data.reduce((sum, item) => sum + item.value, 0);
  const percentage = (value: number) => total > 0 ? `${(value / total * 100).toFixed(1)}%` : "不适用";
  const hovered = data.findIndex(item=>item.label===hoveredKey);
  const safeHovered = hovered < 0 ? null : hovered;
  const setHovered = (index:number|null) => setHoveredKey(index === null ? null : data[index]?.label ?? null);
  const selected = safeHovered == null ? undefined : data[safeHovered];
  const orientations = ["diagonal", "horizontal", "vertical", "diagonalRightToLeft"] as const;
  const fillId = (index: number) => `rain-pie-${instanceId}-${index}`;

  return <>
    <label className="rain-chart-example-control">边界样本 <select aria-label="饼图边界样本" value={scenario} onChange={event=>setScenario(event.target.value as ChartBoundaryScenario)}><option value="normal">正常数据</option><option value="pie-small">1人小类别与长名称</option><option value="pie-remove">移除第二类别</option></select></label>
    {(variantId === "pie-default" || custom) && <label className="rain-chart-example-control">示例状态 <select aria-label="饼图示例状态" value={state} onChange={event => { setState(event.target.value as typeof state); setHovered(null); }}><option value="normal">正常</option><option value="zero">总量为0</option><option value="long">长中心文案</option></select></label>}
    <div className="rain-chart-radial">
      {total <= 0 ? <div className="rain-chart-empty">占比无有效分母</div> : <PieChart key={`${variantId}-${replay}`} className="rain-chart-radial-plot" data={data}
        innerRadius={custom ? 65 : donut ? variantId === "pie-donut" ? 60 : 55 : 0}
        hoveredIndex={safeHovered} onHoverChange={setHovered}
        enterTransition={reduced || !active ? immediate : undefined} enterStaggerScale={reduced || !active ? 0 : 1}>
        {pattern && data.map((item, index) => <PatternLines key={item.label} id={fillId(index)}
          width={index === 3 ? 8 : 6} height={index === 3 ? 8 : 6}
          orientation={[orientations[index]!]} stroke={item.color} strokeWidth={1} />)}
        {gradient && <defs>{data.map((item, index) => <radialGradient key={item.label} id={fillId(index)}>
          <stop offset="0%" stopColor={item.color} stopOpacity={.45} />
          <stop offset="100%" stopColor={item.color} />
        </radialGradient>)}</defs>}
        {data.map((item, index) => <PieSlice key={item.label} index={index}
          color={item.color} fill={pattern || gradient ? `url(#${fillId(index)})` : undefined}
          hoverEffect={grow ? "grow" : "translate"} showGlow={false} animate={!reduced && active} />)}
        {donut && (custom ? <PieCenter defaultLabel={state === "long" ? "综合课程学习情况总人数" : "课程人数"} suffix=" 人" valueClassName="rain-chart-center-value" labelClassName="rain-chart-center-label">
          {({ value, label, isHovered, data: item }) => <div className="rain-chart-center-reading">
            <strong className="rain-chart-center-value" style={{ color: isHovered ? item.color : undefined }}>{value}<small className="ml-0.5 text-[0.65em] font-normal">人</small></strong>
            <span className="rain-chart-center-label">{label}</span>
            <span className="rain-chart-center-label">{isHovered ? `${percentage(item.value)} · 占总人数` : "全部课程"}</span>
          </div>}
        </PieCenter> : <PieCenter defaultLabel="总人数" suffix=" 人" valueClassName="rain-chart-center-value" labelClassName="rain-chart-center-label" />)}
      </PieChart>}
    </div>
    {variantId === "pie-legend" && <InteractiveKey items={data} hovered={safeHovered} onHover={setHovered} />}
    <p className="rain-chart-note" role="status">{total <= 0 ? "总量为0；各类别占比不适用。" : selected ? <><span className="rain-chart-legend-dot" aria-hidden="true" style={{ background: selected.color }} />{`${selected.label}：${selected.value} 人，占 ${percentage(selected.value)}`}</> : `分母为全部类别合计 ${total} 人；各类别互斥。`}</p>
    <VariantTable caption="互斥课程类别与总人数占比" data={data.map(item => ({ 类别: item.label, "人数 · 人": item.value, 占全部比例: percentage(item.value) }))} />
  </>;
}

function RingVariant(props: VariantExampleProps) {
  const { variantId, revision, replay, reduced, active } = props;
  const [hoveredKey, setHoveredKey] = useState<string | null>(null);
  const [storedState, setState] = useVariantSetting("state", "normal", props);
  const [chosenScenario,setScenario] = useVariantSetting("boundaryScenario","normal",props);
  const scenario = chosenScenario.startsWith("ring-") ? chosenScenario : "normal";
  const state = storedState === "long" ? "long" : "normal";
  const thick = variantId === "ring-thick-rings";
  const half = variantId === "ring-half-circle";
  const quarter = variantId === "ring-three-quarter";
  const data = useMemo<RingData[]>(() => {
    const values = [[36, 4, 6], [32, 7, 4], [38, 5, 8]][revision % 3]!;
    return applyRingBoundary([
      { label: exampleLabel("阅读进度", state), value: values[0]!, maxValue: 40, color: seriesColors[0] },
      { label: exampleLabel("练习进度", state), value: values[1]!, maxValue: 12, color: seriesColors[1] },
      { label: exampleLabel("复习进度", state), value: values[2]!, maxValue: 10, color: seriesColors[2] },
    ],scenario);
  }, [revision, state,scenario]);
  const hoveredIndex = data.findIndex(item=>item.label===hoveredKey);
  const hovered = hoveredIndex < 0 ? null : hoveredIndex;
  const setHovered = (index:number|null) => setHoveredKey(index === null ? null : data[index]?.label ?? null);
  const selected = hovered == null ? undefined : data[hovered];
  const drawable = data.every(item=>item.maxValue>0 && item.value>=0 && item.value<=item.maxValue);
  const percentage = (item:RingData) => item.maxValue > 0 ? `${(item.value/item.maxValue*100).toFixed(1)}%` : "不适用";
  return <>
    <label className="rain-chart-example-control">边界样本 <select aria-label="进度环边界样本" value={scenario} onChange={event=>setScenario(event.target.value as ChartBoundaryScenario)}><option value="normal">正常数据</option><option value="ring-zero">完成0 / 目标100</option><option value="ring-full">完成100 / 目标100</option><option value="ring-zero-goal">目标为0</option><option value="ring-over">完成120 / 目标100</option></select></label>
    {(variantId === "ring-default" || half || quarter) && <label className="rain-chart-example-control">示例状态 <select aria-label="进度环示例状态" value={state} onChange={event => { setState(event.target.value as typeof state); setHovered(null); }}><option value="normal">正常</option><option value="long">长中心文案</option></select></label>}
    <div className="rain-chart-radial">
      {!drawable ? <div className="rain-chart-empty">{scenario === "ring-zero-goal" ? "目标为0，进度不适用" : "超目标"}；保留真实当前值和各目标分母，不生成进度环。</div> : <RingChart key={`${variantId}-${replay}`} className="rain-chart-radial-plot" data={data}
        hoveredIndex={hovered} onHoverChange={setHovered} strokeWidth={thick ? 18 : 12} ringGap={thick ? 8 : 6}
        startAngle={half || quarter ? -Math.PI : undefined} endAngle={half ? 0 : quarter ? Math.PI / 2 : undefined}
        enterTransition={reduced || !active ? immediate : undefined} enterStaggerScale={reduced || !active ? 0 : 1}>
        {data.map((item, index) => <Ring key={item.label} index={index} color={item.color}
          animate={!reduced && active} lineCap={variantId === "ring-flat-caps" ? "butt" : "round"} />)}
        <RingCenter valueClassName="rain-chart-center-value" labelClassName="rain-chart-center-label">
          {({ data: item }) => <div className="rain-chart-center-reading">
            <strong className="rain-chart-center-value">{(item.value / item.maxValue * 100).toFixed(1)}%</strong>
            <span className="rain-chart-center-label">{item.label}</span>
          </div>}
        </RingCenter>
      </RingChart>}
    </div>
    {variantId === "ring-legend" && <InteractiveKey items={data} hovered={hovered} onHover={setHovered} progress />}
    <p className="rain-chart-note" role="status">{selected ? `${selected.label}：${selected.value}/${selected.maxValue} 项，${percentage(selected)}` : "中心默认展示首项目标；每环使用自己的目标分母，不合计为总进度。"}</p>
    <VariantTable caption="独立目标的当前值、分母和进度" data={data.map(item => ({ 独立目标: item.label, "当前 · 项": item.value, "目标 · 项": item.maxValue, 进度: percentage(item) }))} />
  </>;
}

const radarMetricLabels = ["理解", "分析", "应用", "表达", "协作", "创造"];
function RadarVariant({ variantId, revision, replay, reduced, active }: VariantExampleProps) {
  const [hovered, setHovered] = useState<number | null>(null);
  const triangle = variantId === "radar-triangle" || variantId === "radar-grid-only";
  const hexagon = variantId === "radar-hexagon";
  const single = variantId === "radar-single-series";
  const minimal = variantId === "radar-minimal";
  const metrics = useMemo<RadarMetric[]>(() => radarMetricLabels.slice(0, triangle ? 3 : hexagon ? 6 : 5)
    .map((label, index) => ({ key: `metric${index}`, label })), [triangle, hexagon]);
  const data = useMemo<RadarData[]>(() => {
    const profiles = single ? [
      [[92, 38, 78, 45, 63, 58]], [[88, 43, 75, 53, 61, 62]], [[95, 32, 73, 49, 69, 56]],
    ] : [
      [[88, 65, 91, 56, 74, 68], [62, 86, 57, 82, 69, 89]],
      [[84, 70, 88, 64, 72, 72], [68, 82, 62, 79, 76, 84]],
      [[91, 59, 86, 60, 80, 66], [59, 93, 63, 78, 64, 92]],
    ];
    return (single ? ["示例课程"] : ["课程 A", "课程 B"])
      .map((label, series) => ({ label, color: seriesColors[series], values: Object.fromEntries(metrics.map((metric, index) =>
        [metric.key, profiles[revision % 3]![series]![index]!])) }));
  }, [single, metrics, revision]);
  const safeHovered = hovered != null && Number.isInteger(hovered) && hovered >= 0 && hovered < data.length ? hovered : null;
  return <>
    <div className="rain-chart-radial">
      <RadarChart key={`${variantId}-${replay}`} className="rain-chart-radial-plot" data={data} metrics={metrics}
        margin={48} levels={minimal ? 3 : 5} animate={!reduced && active} hoveredIndex={safeHovered} onHoverChange={setHovered}
        enterTransition={reduced || !active ? immediate : undefined} staggerScale={reduced || !active ? 0 : 1} enterDurationMs={reduced || !active ? 0 : undefined} motionReplayKey={String(replay)}>
        <RadarGrid showLabels={!hexagon && !minimal} />
        {!hexagon && !minimal && variantId !== "radar-grid-only" && <RadarAxis />}
        <RadarLabels fontSize={12} offset={16} />
        {data.map((item, index) => <RadarArea key={item.label} index={index} color={item.color}
          showPoints={!hexagon && !single && !minimal} showStroke={!hexagon} showGlow={!hexagon && variantId !== "radar-grid-only"} />)}
      </RadarChart>
    </div>
    <p className="rain-chart-note">{metrics.length} 个维度共用 0–100 分量程；均为示例评分，未混合不同单位。</p>
    <ExampleLegend items={data.map((item, index) => ({ label: item.label, value: 0, color: item.color ?? seriesColors[index]! }))} hovered={safeHovered} onHover={setHovered} />
    <VariantTable caption="同尺度能力评分 · 分" data={data.map(item => ({ 课程: item.label, ...Object.fromEntries(metrics.map(metric => [`${metric.label} · 分`, item.values[metric.key]])) }))} />
  </>;
}

export function RadialVariant(props: VariantExampleProps) {
  if (!RADIAL_VARIANT_IDS.includes(props.variantId as typeof RADIAL_VARIANT_IDS[number])) throw new Error(`Unknown radial variant: ${props.variantId}`);
  if (props.variantId.startsWith("pie-")) return <PieVariant {...props} />;
  if (props.variantId.startsWith("ring-")) return <RingVariant {...props} />;
  return <RadarVariant {...props} />;
}
